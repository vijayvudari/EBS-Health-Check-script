# EBS Health Check Tool



## Release information

Current release: 3.0.8

Date of release: August 11, 2023



## Introduction

This tool provides a baseline for evaluating your EBS deployment for its cloud-readiness and production-readiness. The tool consists of two parts: **data collection** and **report generation**. The data collection part has three components: bdecheck, oracheck/exacheck, and manual check.



## Data Collection: BDE Check

**You do not need to run this check if your database version is 19c or higher. If your database version is 19c+, please proceed to "Data Collection: ORA/EXA Check".**

This is one of three data pieces for generating the final report. You may find the file in this support document https://support.oracle.com/epmos/faces/DocumentDisplay?_afrLoop=490979140825047&parent=DOCUMENT&sourceId=2308463.1&id=174605.1&_afrWindowMode=0&_adf.ctrl-state=4llm0bpyc_53 or directly at this link https://support.oracle.com/epmos/main/downloadattachmentprocessor?parent=DOCUMENT&sourceId=174605.1&attachid=174605.1:SCRIPT_12108&clickstream=yes.

You must run the BDE Check on an APP node as the APPS user. This generates an html file that will be used to create the final report.


### Prerequisites - BDE Check

1. Download the script from [this link](https://support.oracle.com/epmos/main/downloadattachmentprocessor?parent=DOCUMENT&sourceId=174605.1&attachid=174605.1:SCRIPT_12108&clickstream=yes).


### Steps to Gather BDE Check Information

1. Upload the `bde_chk_cbo_1208.sql` script to any APP node.
2. On that node, run the EBS environment file for that server with the "run" option. Generally this environment file is found at `/u01/install/APPS/EBSapps.env` but your environment may vary.
```
source /your/environment/file/here.env run
```
3. Run sqlplus using your credentials to log in to the database.
```
sqlplus [username]/[password]
```
4. Run the script file. This generates a spool file called `bde_chk_cbo_report.html` and a log file called `bde_chk_cbo.log`.
```
@bde_chk_cbo_1208.sql
```
5. Download the spool file to your local machine.



## Data Collection: ORA/EXA Check

This is one of three data pieces needed to generate the final report. You may find the AHF installation file at https://support.oracle.com/epmos/faces/DocContentDisplay?_afrLoop=491251169771167&id=2550798.1&_afrWindowMode=0&_adf.ctrl-state=4llm0bpyc_102: click "Download AHF" and follow the steps to install this on your EBS deployment.

You must run the ORA Check or EXA Check on a DB node. While running the ORA or EXA Check, you should choose the setting to gather data across all the DB nodes at once instead of individually since the report generation step only accepts one ORA/EXA report. This will generate a directory of multiple files - you will need `upload/#######_orachk_results.json` and `upload/orachk_recommendations.json` to create the final report.


### Prerequisites - ORA/EXA Check

1. Download the AHF installer at [this link](https://support.oracle.com/epmos/faces/DocContentDisplay?_afrLoop=491251169771167&id=2550798.1&_afrWindowMode=0&_adf.ctrl-state=4llm0bpyc_102).


### Steps to Gather ORA/EXA Check Information

1. Upload the installation zip to a DB node. Then, unzip the file on that machine.
2. Install AHF on that machine by following the instructions in the unzipped README.txt.
3. Run the following:
```
./tfactl orachk
```
or, if you are using Exadata,
```
./tfactl exachk
```
4. Zip the generated folder, then download it to your local machine. Here is a possible location of where the folder `orachk_[DB NODE NAME]_[REST OF FOLDER NAME]` would be generated: `/u01/app/oracle.ahf/data/[DB NODE NAME]/orachk/user_root/output`.



## Data Collection: Manual Check

This is one of three data pieces needed to generate the final report. Technically, there will be at least two files you will generate in this section.

There are two types of data files to gather: a single SQL query JSON file, and a number of shell command JSON files equal to the total number of nodes. The collected parameters are used in checks that are not covered by the BDE report or the ORA/EXA checks.


### Prerequisites - Manual Check

Please ensure you can find the two scripts `scripts_sh.sh` and `scripts_sql.sql` in the CODE deliverable. They should be located at `CODE/src`.


### Steps to Gather Manual Check Information

1. Generate the SQL query JSON file. The steps for collecting the SQL data are nearly identical to that of the BDE check. The steps are reprinted below for your convenience:
    1. Upload the `scripts_sql.sql` script to any APP node.
    2. On that node, run the EBS environment file for that server with the "run" option. Generally this environment file is found at `/u01/install/APPS/EBSapps.env` but your environment may vary.
    ```
    source /your/environment/file/here.env run
    ```
    3. Run sqlplus using the apps user credentials to log in to the database.
    ```
    sqlplus [username]/[password]
    ```
    4. Run the script file. This generates a data file called `sql_data.json` and a log file called `man_chk.log`.
    ```
    @scripts_sql.sql
    ```
    5. Download the data file to your local machine.
2. Generate the shell command JSON files. You will need to run the script for collecting shell data on EVERY node you intend to use on the current execution of the EBS health check program. On every APP and DB node:
    1. Upload the `scripts_sh.sh` script to the node.
    2. On that node, run the EBS environment file for that server with the "run" option. Generally this environment file is found at `/u01/install/APPS/EBSapps.env` for APP nodes or `$HOME/*.env` for DB nodes but your environment may vary.
    ```
    source /your/environment/file/here.env run
    ```
    3. Enable permissions for the script:
        - Owner: if `ls -l` does not show you as the owner of `scripts_sh.sh`, run `chown [YOUR_USER] scripts_sh.sh`
        - Execution permissions: if `ls -l` does not show execution permissions for this file, e.g. `-rw-r--r--` as opposed to `-rwxr--r--`, run `chmod u+x scripts_sh.sh`
    4. Run the script file. This generates a data file called `shoutput.json`. Please keep a record of the script output to the terminal - this may help with debugging should a problem arise.
    ```
    ./scripts_sh.sh
    ```
    5. Download the data file to your local machine. We recommend you rename the file so that it correlates to the node from which it was run (e.g. "shoutput_EBSAPP01.json" was run from "EBSAPP01" node).



## Report Generation

This step relies heavily on Python3 on your local machine, or whichever environment you want to use to generate the final report. We recommend you use your local machine for convenience. Please carefully read the **Prerequisites - Installation** step for the relevant operating system of your report generation environment.

There will be two parts for report generation: config file and actual report generation. The config file part requires that you gather all the information in **Prerequisites - Config** before continuing. The actual report generation part uses the config file you created previously to generate the final report.


### Prerequisites - Installation on Mac/Linux

**This section only applies to Mac/Linux users. For Windows users, please go to the below section**. If you are running these checks on your own machine, please ensure that the following prerequisites are satisfied.

1. **Python version**: This program has been tested on Python 3.7+ and requires Python 3.x to run. Performance on other versions may vary. If your machine does not have Python 3 installed, please install it - you can find the most up-to-date version of Python 3 for your OS at https://www.python.org/downloads/. To check if you have Python 3, open a terminal window and run
    ```
    which python3
    ```
    If the terminal gives you the empty string, you do not have Python 3 installed. To check the version of Python, you may run:
    ```
    python3 --version
    ```
    To install Python 3, please follow these instructions:
    - Access the above link and download the latest version of Python 3 (yellow download button).
    - Run the installer and use all defaults in the installation wizard.
    - Once Python has been fully installed, open a terminal window and run the following:
        ```
        python3
        ```
        If the terminal does not immediately respond with the interactive Python interpreter (such as the following code block), please retry the installation from the link above.
        ```
        Python 3.9.6 (v3.9.6:91ad05b055, Feb 30 2020, 24:60:60) 
        [Clang 6.0 (clang-600.0.57)] on darwin
        Type "help", "copyright", "credits" or "license" for more information.
        >>> 
        ```
2. **Pip version**: This program uses pip3 to manage packages. Please ensure that it is installed and up-to-date. **If you installed Python 3 in step 1, the installer should have installed pip3 for you.** Otherwise, you can install pip by downloading the get-pip.py script at https://bootstrap.pypa.io/get-pip.py, then run it as such in your terminal:
    ```
    python3 get-pip.py
    ```
    You can check if you have pip already by running:
    ```
    which pip
    ```
    or
    ```
    which pip3
    ```
    You may have both python 2.x and 3.x installed; similarly "pip3" will be the alias for the pip installer for python 3.x libraries, whereas "pip" may install a python 2.x version of a library. Therefore you would run `which pip3` and `pip3` for all pip commands. **As of August 1 2022, the link above gets you pip version 22.2.1, which is incompatible with Python versions older than 3.7.**
3. **Install requirements**: The program depends on the modules specified in the `requirements.txt` file. Using your terminal, navigate to the directory where `requirements.txt` is located (use `cd /where/your/file/is/located`), then run the following command to install dependencies:
    ```
    pip3 install -r requirements.txt
    ```
    ***NOTE: if during execution, some Python script fails with a message resembling "Missing library x", you should install the library using `pip3 install x`, then attempt to run the script after the library installs.***

### Prerequisites - Installation on Windows

**This section only applies to Windows users. For Mac/Linux users, please go to the above section**. If you are running these checks on your own machine, please ensure that the following prerequisites are satisfied.

1. **Bash Terminal**: You will need to use a bash terminal for running these scripts. This is not the same as Windows Command Prompt or Windows PowerShell. This guide uses Git Bash as the bash terminal of choice, which can be downloaded here: https://git-scm.com/downloads (the Windows downloadable is mainly for downloading Git, with Git Bash as a side option that you will need to check in the installation wizard). More detailed installation instructions for Git Bash below:
   - Go to the link above and download the Git installer. Generally you download the 64-bit installer, unless you are running this on a Windows machine that does not have a 64-bit processer (these are generally older computers). You may refer to guides like [this one](https://support.lenovo.com/us/en/solutions/ht117173-how-to-know-if-my-computer-is-32-bit-or-64-bit-windows) or search online to find out whether your machine is 64-bit or 32-bit.
   - Run the installation wizard. This will install Git, with the option to install Git Bash. Use all default options, but on the step where it asks whether to install Git Bash, make sure that box is checked.
   - Once Git and Git Bash are successfully installed, open Git Bash. If you cannot locate Git Bash on Cortana or by searching your apps, you will have to rerun the installation wizard. Once you have opened Git Bash, pin the app to your taskbar by right-clicking the Git Bash icon on your taskbar and selecting "pin app to taskbar". Some practice you can do now that you have Git Bash is to open multiple Git Bash terminals, as you may have one for running scripts and one for editing files. To open multiple terminal windows, right click on the Git Bash icon in your taskbar and select the "Git Bash" option, and repeat for more Git Bash windows.
2. **Python version**: This program has been tested on Python 3.7+ and requires Python 3.x to run. Performance on other versions may vary. If your machine does not have Python 3 installed, please install it - you can find the most up-to-date version of Python 3 for your OS at https://www.python.org/downloads/. To check if you have Python 3, open Git Bash and run
    ```
    which python3
    ```
    If Git Bash gives you the empty string, you do not have Python 3 installed. Additionally, if it gives you a directory ending with `\Microsoft\WindowsApps` you will need to install Python 3.x since using the "python.exe" under this directory will redirect you to the Microsoft Store page rather than actually run Python. To check the version of Python, you may run:
    ```
    python3 --version
    ```
    To install Python, please follow these instructions:
    - Access the above link and download the latest Python 3 installer for Windows (yellow download button).
    - In the installation wizard, there will be an option to add the installation directory to Path - make sure this box is checked. Select the default installation.
    - Once Python has been fully installed, check your Path environment variable. You can do this by searching "environment variables" in Cortana or in Control Panel. This opens a properties window with an "Edit Environment Variables" button. Click this, then select the "Path" user environment variable and click the top edit button. If the installation was successful, you should see a string like `%USERPROFILE%\AppData\Local\Programs\Python\Python39` where the last folder is the Python version (this one is 3.9). **If you do not see any strings resembling the location of where you just installed Python, please locate this directory (it will contain "python.exe") and add a new environment variable with this directory.**
    - Finally, you will need to modify your Git Bash by adding an alias. Open a Git Bash terminal or use an existing one and run:
        ```
        echo 'alias python3="winpty python.exe"' > ~/.bashrc
        ```
        then close and reopen Git Bash so that the alias is loaded onto the new Git Bash window. You can test this by running the following in a Git Bash terminal:
        ```
        python3
        ```
        If the terminal does not immediately respond with the interactive Python interpreter (such as the following code block), please retry the installation from the link above.
        ```
        Python 3.9.6 (v3.9.6:adb15c001, Jan 32 9999, 25:61:61) 
        [Clang 6.0 (clang-600.0.57)] on darwin
        Type "help", "copyright", "credits" or "license" for more information.
        >>> 
        ```
3. **Pip version**: This program uses pip3 to manage packages. Please ensure that it is installed and up-to-date. **If you installed Python 3 in step 2, the installer should have installed pip3 for you.** Otherwise, you can install pip by downloading the get-pip.py script at https://bootstrap.pypa.io/get-pip.py, then run it as such in your terminal:
    ```
    python3 get-pip.py
    ```
    You can check if you have pip already by running:
    ```
    which pip
    ```
    or
    ```
    which pip3
    ```
    You may have both python 2.x and 3.x installed; similarly "pip3" will be the alias for the pip installer for python 3.x libraries, whereas "pip" may install a python 2.x version of a library. Therefore you would run `which pip3` and `pip3` for all pip commands. **As of August 1 2022, the link above gets you pip version 22.2.1, which is incompatible with Python versions older than 3.7.**
4. **Install requirements**: The program depends on the modules specified in the `requirements.txt` file. Using your terminal, navigate to the directory where `requirements.txt` is located (use `cd /where/your/file/is/located`), then run the following command to install dependencies:
    ```
    pip3 install -r requirements.txt
    ```
    ***NOTE: if during execution, some Python script fails with a message resembling "Missing library x", you should install the library using `pip3 install x`, then attempt to run the script after the library installs.***


### Prerequisites - Config

Please ensure you have the following information from your EBS deployment:

- VM server information **for each node** you have:
    - Server name
    - Type of node (application, database, or both)
    - Full path† of the SH output file (e.g. `/Users/user/Desktop/shoutput.json`)
- Database information
    - Full path† of the SQL output file (e.g. `/Users/user/Desktop/sql_data.json`)
- EBS information
    - EBS version
- Report information
    - Full path† of the BDE Check output file
    - Full paths† of the ORA Check or EXA Check output file

†: You will need to collect ALL of the data files prior to running the config_gen script.


### Steps To Generate the Report

Prior to these steps, you may find it easier to group all the data files into the same directory. The number of data files will always be 1 HTML file and 3+X JSON files where X is the total number of APP and DB nodes you are running this report on.

1. Install python requirements.
    - Navigate to the `CODE` directory. Then, run the following:
        ```
        pip3 install -r requirements.txt
        ```
2. Generate the config file.
    - Navigate to the `CODE/src/report` directory. Then, run the following:
        ```
        python3 config_gen.py
        ```
    - Answer all prompts as best as you can. If you are not quite sure what to put for any prompt, you can always come back to it after the config file `config.py` has been generated. The script will let the user know when the input is invalid (e.g. entering "one" for a numeric value or "noip" for an IP address).
    - Once `config.py` has been generated, double-check the file to make sure all file locations are entered properly. You can also make any corrections directly to the config file as necessary.
3. Generate the report.
    - Run the following:
        ```
        python3 generate_report.py
        ```
    - Please keep a record of the script output to the terminal - this may help with debugging should a problem arise.

After script completion, a `healthcheck-report.html` file should have been generated in the `CODE` directory of this app.

# EBS Health Check Report

## Navigating The Report

A detailed Health Check report is generated after executing the healthcheck scripts on an EBS environment. The report will provide findings for database, application-tier and technology components along with recommendations for any checks that have warning or failed status.

The Executive Summary has a breakdown of the Health Checks by status - Passed, Warning, N/A, Failed, and Error checks.

![Summary](https://objectstorage.us-phoenix-1.oraclecloud.com/n/orasenatdoracledigital01/b/AppsGenie/o/Images%2Fhc1.png)

You can view the list of checks by clicking on the count for that status.

![Status Count](https://objectstorage.us-phoenix-1.oraclecloud.com/n/orasenatdoracledigital01/b/AppsGenie/o/Images%2Fhc2.png)

Click on any of the checks to further navigate to the specifics of that check.

![Navigate To Check](https://objectstorage.us-phoenix-1.oraclecloud.com/n/orasenatdoracledigital01/b/AppsGenie/o/Images%2Fhc3.png)

Recommendation section for a check includes relevant information of the benefits and impacts of making the change, risks involved if the change is not implemented, and a detailed action plan for implementing the change. 

![Navigate To Check](https://objectstorage.us-phoenix-1.oraclecloud.com/n/orasenatdoracledigital01/b/AppsGenie/o/Images%2Fhc4.png)

For every check, clicking on the status will expand the detail section that shows the output from the command(s) executed for that check.

![Navigate To Check](https://objectstorage.us-phoenix-1.oraclecloud.com/n/orasenatdoracledigital01/b/AppsGenie/o/Images%2Fhc5.png)

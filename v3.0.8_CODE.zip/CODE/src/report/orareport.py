import json
from bs4 import BeautifulSoup
import os.path

filepath = os.path.dirname(os.path.abspath(__file__))

def repNewLines(s, soup, report):
    lines = s.split('\\n')
    soup.append(lines[0])
    for l in lines[1:]:
        soup.append(report.new_tag('br'))
        soup.append(l)

def fileCheck(fn):
    try:
        open(fn, 'r')
        return 1
    except IOError:
        print('Error: ' + fn +' not found.')
        return 0

template = filepath+'/../../healthcheck-report.html'
fileCheck(template)
with open(template) as inf:
    txt = inf.read()
    report = BeautifulSoup(txt, 'html.parser')

file1 = filepath+'/../data/tmp/ora.json'
fileCheck(template)
with open(file1) as json_file:
    data = json.load(json_file)

oraDetails = report.findAll('td', class_ = 'oradetail')
count = len(oraDetails)
getSumm = []
databaseTypes = ['OS']
order = 1
h1s = report.findAll('h1', class_ = 'sub summary')
order += len(h1s)

def getBrackets(summ, html):
    curr = summ
    curr = curr.replace('<pre>', '')        
    curr = curr.replace('</pre>', '')
    while curr.find('<br>') != -1:
        idx = curr.find('<br>')
        html.append(curr[:idx])
        html.append(report.new_tag('br'))
        curr = curr[idx+4:]
    html.append(curr)
    return html


##Parsing the data into HTML
##Database Server
##Creating Recommendations, each item is one recommendation
for item in data:
    status = 'PASS'
    recoStatus = 'PASS'
    title = report.new_tag('h1', attrs ={'class': 'sub summary', 'id': 'reco' + str(order)})
    title.append(str(order) + ': ' + data[item]['name'])
    order += 1

    #if data[item]['type'] in databaseTypes:
    params = data[item]['parameters']
    fails = {}

    summaryTitle = report.new_tag('h2', attrs = {'class': 'summary'})
    summaryTitle.append('Summary:')
    summary = report.new_tag('h2')
    summary.append(data[item]['message'])

    #summaryType = report.new_tag('h2', attrs = {'class': 'summary'})
    #summaryType.append(data[item]['type'])

    findingsTitle = report.new_tag('h2', attrs = {'class': 'summary'})
    findingsTitle.append('Findings:')
    findings = report.new_tag('h2')
    findingsCrit = report.new_tag('h2')
    findingsTable = report.new_tag('table', attrs ={'class': 'findings'})

    for param in params:
        if param['status'] != 'PASS':
            status = param['status']
            if param['instance'] != '':
                paramName = data[item]['node'] + ':' + param['instance']
            else:
                paramName = data[item]['node']
            fails[paramName] = param['details']

    getSumm.append([order-1, data[item]['name'], status])
    if not bool(fails):
        findings.append('The check has passed all requirements')
    else:
        findings.append('The following parameters have been identified as different from the recommended settings')
        findingsCrit.append('Critical Parameters in a Failed State')
        header = report.new_tag('thead')
        hRow = report.new_tag('tr')
        hParam = report.new_tag('th')
        hParam.append('Parameter')
        hSetting = report.new_tag('th')
        hSetting.append('Recommended Setting')
        hRow.append(hParam)
        hRow.append(hSetting)
        header.append(hRow)
        body = report.new_tag('tbody')
        for fail in fails:
            bRow = report.new_tag('tr')
            bParam = report.new_tag('td')
            bSetting = report.new_tag('td')
            bParam.append(fail)
            bSetting.append('This parameter requires attention')
            bRow.append(bParam)
            bRow.append(bSetting)
            body.append(bRow)
        findingsTable.append(header)
        findingsTable.append(body)

    recommendationTitle = report.new_tag('h2', attrs = {'class': 'summary'})
    recommendationTitle.append('Recommendation:')
    recommendation = report.new_tag('h2')
    recommendation = getBrackets(data[item]['recommendation'], recommendation)

    if len(params) != 0:
        paramsTable = report.new_tag('table', attrs={'class': 'res'})
        paramsHead = report.new_tag('thead')
        paramsHeadRow = report.new_tag('tr')
        paramsHeadName = report.new_tag('th')
        paramsHeadName.append('Parameter')
        paramsHeadStatus = report.new_tag('th')
        paramsHeadStatus.append('Status')
        paramsHeadRow.append(paramsHeadName)
        paramsHeadRow.append(paramsHeadStatus)
        paramsHead.append(paramsHeadRow)
        paramsTable.append(paramsHead)

        paramsBody = report.new_tag('tbody')
        paramName = ''
        for param in params:
            paramsBodyRow = report.new_tag('tr')
            paramsBodyName = report.new_tag('td')
            paramsBodyStatus = report.new_tag('td')
            paramsDetailRow = report.new_tag('tr')
            paramsDetail = report.new_tag('td', attrs= {'class': 'oradetail', 'colspan': '2'})
            paramsLogWrapper = report.new_tag('pre', attrs = {'style': 'text-align: left; white-space: pre-wrap'})
            paramsLog = report.new_tag('code')
            if param['instance'] != '':
                paramName = data[item]['node'] + ':' + param['instance']
            else:
                paramName = data[item]['node']
            paramsBodyName.append(paramName)
            
            if param['status'] == 'PASS':
                paramsButton = report.new_tag('button', attrs={'class': 'pass orabutton', 'onclick': 'toggleOraDetail('+str(count)+')'})
                paramsButton.append('PASS')
            elif param['status'] == 'FAIL' or param['status'] == 'CRITICAL':
                paramsButton = report.new_tag('button', attrs={'class': 'fail orabutton', 'onclick': 'toggleOraDetail('+str(count)+')'})
                paramsButton.append('FAIL')
            else:
                paramsButton = report.new_tag('button', attrs={'class': 'warn orabutton', 'onclick': 'toggleOraDetail('+str(count)+')'})
                paramsButton.append('WARNING')
            count += 1

            if len(param['details']) > 1:
                repNewLines(param['details'], paramsLog, report)
            else:
                paramsLog.append('none')

            paramsBodyStatus.append(paramsButton)
            paramsBodyRow.append(paramsBodyName)
            paramsBodyRow.append(paramsBodyStatus)
            paramsBody.append(paramsBodyRow)
            paramsLogWrapper.append(paramsLog)
            paramsDetail.append(paramsLogWrapper)
            paramsDetailRow.append(paramsDetail)
            paramsBody.append(paramsDetail)
        paramsTable.append(paramsBody)
    
    ##Status Summary
    recoStatusTitle = report.new_tag('h2', attrs = {'class': 'summary'})
    recoStatusTitle.append('Status: ')
    if status == 'PASS':
        recoStatus = report.new_tag('h2', attrs = {'class': 'recoStatus pass'})
        recoStatus.append('Pass')
    elif status == 'FAIL' or status == 'CRITICAL':
        recoStatus = report.new_tag('h2', attrs = {'class': 'recoStatus fail'})
        recoStatus.append('Fail')
    else:
        recoStatus = report.new_tag('h2', attrs = {'class': 'recoStatus warn'})
        recoStatus.append('Warning')

    report.find(id='recommendations').append(title)
    report.find(id='recommendations').append(recoStatusTitle)
    report.find(id='recommendations').append(recoStatus)
    report.find(id='recommendations').append(summaryTitle)
    report.find(id='recommendations').append(summary)
    report.find(id='recommendations').append(findingsTitle)
    report.find(id='recommendations').append(findings)
    if bool(fails):
        report.find(id='recommendations').append(findingsCrit)
        report.find(id='recommendations').append(findingsTable)
    report.find(id='recommendations').append(recommendationTitle)
    report.find(id='recommendations').append(recommendation)
    if len(params) != 0:
        report.find(id='recommendations').append(paramsTable)

f = open(template, 'w')
f.write(report.prettify())
f.close()

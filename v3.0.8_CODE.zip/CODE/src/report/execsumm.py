from bs4 import BeautifulSoup
import os.path

filepath = os.path.dirname(os.path.abspath(__file__))

VERSION = "3.0.8" # UPDATE THIS WHENEVER UPGRADING VERSION

def fileCheck(fn):
    try:
        open(fn, 'r')
        return 1
    except IOError:
        print('Error: ' + fn +' not found.')
        return 0

def evaluate(x):
    eval = 1
    if x == 'exclaim':
        eval = 0.5
    elif x == 'cross':
        eval = 0.25
    return eval

file1 = filepath+'/../../healthcheck-report.html'
fileCheck(file1)
with open(file1) as inf:
    txt = inf.read()
    report = BeautifulSoup(txt, 'html.parser')

exeSumm = report.find('div', {'id': 'executive'})
exeSumm = exeSumm.findAll('td', {'class': 'status'})

def add_version(report):
    version = report.find('span', attrs={'class': 'version'})
    version.clear()
    version.append(f"v{VERSION}")

def embedScore(report):

    statuses = {"pass": 0, "warn": 0, "na": 0, "fail": 0, "ERROR": 0}
    findings = []
    statusTable = report.find('div', attrs={'id': 'recommendations'})
    titleTable = statusTable.findAll('h1', attrs={'class': 'sub summary'})
    statusTable = statusTable.findAll('h2', attrs={'class': 'recoStatus'})
    
    for item in statusTable:
        if len(item['class']) != 2:
            continue
        if item['class'][1] == 'pass':
            findings.append('pass')
            statuses["pass"] += 1
        elif item['class'][1] == 'warn':
            findings.append('warn')
            statuses["warn"] += 1
        elif item['class'][1] == 'na':
            findings.append('na')
            statuses["na"] += 1
        elif item['class'][1] == 'fail':
            findings.append('fail')
            statuses["fail"] += 1
        elif item['class'][1] == 'ERROR':
            findings.append('ERROR')
            statuses["ERROR"] += 1
        else:
            continue

    totals = report.find('div', attrs={'id': 'executive'})
    totals = totals.findAll('th', attrs={'class': 'status'})
    passes = report.new_tag('a', attrs={'class': 'beta', 'onclick': 'toggleExeSummBeta(0)'})
    warns = report.new_tag('a', attrs={'class': 'beta', 'onclick': 'toggleExeSummBeta(1)'})
    fails = report.new_tag('a', attrs={'class': 'beta', 'onclick': 'toggleExeSummBeta(2)'})
    nas = report.new_tag('a', attrs={'class': 'beta', 'onclick': 'toggleExeSummBeta(3)'})
    ERRORS = report.new_tag('a', attrs={'class': 'beta', 'onclick': 'toggleExeSummBeta(4)'})
    if len(totals) == 5:
        totals[0].clear()
        passes.append(str(statuses["pass"]))
        totals[0].append(passes)
        totals[1].clear()
        warns.append(str(statuses["warn"]))
        totals[1].append(warns)
        totals[2].clear()
        fails.append(str(statuses["fail"]))
        totals[2].append(fails)
        totals[3].clear()
        nas.append(str(statuses["na"]))
        totals[3].append(nas)
        totals[4].clear()
        ERRORS.append(str(statuses["ERROR"]))
        totals[4].append(ERRORS)

    details = report.find('div', attrs={'id': 'executive'})
    details = details.findAll('p', attrs={'class': 'detail'})
    if len(details) == 5:
        details[0].clear()
        details[1].clear()
        details[2].clear()
        details[3].clear()
        details[4].clear()
        for i in range(len(findings)):
            title = titleTable[i].text
            order = i+1
            if findings[i] == 'pass':
                links = report.new_tag('a', attrs={'href': '#reco' + str(order), 'class': 'pass'})
                links.append(title)
                details[0].append(links)
                details[0].append(report.new_tag('br'))
            elif findings[i] == 'warn':
                links = report.new_tag('a', attrs={'href': '#reco' + str(order), 'class': 'warn'})
                links.append(title)
                details[1].append(links)
                details[1].append(report.new_tag('br'))
            elif findings[i] == 'fail':
                links = report.new_tag('a', attrs={'href': '#reco' + str(order), 'class': 'fail'})
                links.append(title)
                details[2].append(links)
                details[2].append(report.new_tag('br'))
            elif findings[i] == 'na':
                links = report.new_tag('a', attrs={'href': '#reco' + str(order), 'class': 'na'})
                links.append(title)
                details[3].append(links)
                details[3].append(report.new_tag('br'))
            elif findings[i] == 'ERROR':
                links = report.new_tag('a', attrs={'href': '#reco' + str(order), 'class': 'ERROR'})
                links.append(title)
                details[4].append(links)
                details[4].append(report.new_tag('br'))
            else:
                print('error invalid result type: '+ findings[i])


embedScore(report)
add_version(report)
f = open(file1, 'w')
f.write(report.prettify())
f.close()
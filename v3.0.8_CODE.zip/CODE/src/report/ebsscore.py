from bs4 import BeautifulSoup
import os.path

filepath = os.path.dirname(os.path.abspath(__file__))

def fileCheck(fn):
    try:
        open(fn, 'r')
        return 1
    except IOError:
        print('Error: ' + fn +' not found.')
        return 0

def evaluate(x):
    eval = 1
    if x == 'exclaim':
        eval = 0.5
    elif x == 'cross':
        eval = 0.25
    return eval

file1 = filepath+'/../../healthcheck-report.html'
fileCheck(file1)
with open(file1) as inf:
    txt = inf.read()
    report = BeautifulSoup(txt, 'html.parser')

def embedScore(report):
    statuses = {"pass": 0, "warn": 0, "fail": 0, "na": 0, "error": 0, "skip": 0}
    statusTable = report.find('div', attrs={'id': 'recommendations'})
    statusTable = statusTable.findAll('h2', attrs={'class': 'recoStatus'})
    for item in statusTable:
        if len(item['class']) != 2:
            continue
        status = item['class'][1]
        if status == 'pass':
            statuses["pass"] += 1
        elif status == 'warn':
            statuses["warn"] += 1
        elif status == 'fail':
            statuses["fail"] += 1
        elif status == 'na':
            statuses["na"] += 1
        elif status == 'ERROR':
            statuses["error"] += 1
        else:
            print(f"WARNING: {status} not recognized. Valid statuses are pass, warn, fail, na/ERROR.")

    totals = report.find('div', attrs={'id': 'title_bar'})
    totals = totals.findAll('td', attrs={'class': 'totals'})
    if len(totals) == 6:
        totals[0].clear()
        totals[0].append(str(sum(statuses.values())))
        totals[1].clear()
        totals[1].append(str(statuses["pass"]))
        totals[2].clear()
        totals[2].append(str(statuses["warn"]))
        totals[3].clear()
        totals[3].append(str(statuses["fail"]))
        totals[4].clear()
        totals[4].append(str(statuses["na"]))
        totals[5].clear()
        totals[5].append(str(statuses["error"]))

    score = (statuses["pass"] + 0.5 * statuses["warn"]) / (statuses["pass"] + statuses["warn"] + statuses["fail"])
    score = int(score*100)
    report.find('h1', {'class': 'score'}).clear()
    report.find('h1', {'class': 'score'}).append(f'Score: {str(score)}/100')

embedScore(report)
f = open(file1, 'w')
f.write(report.prettify())
f.close()
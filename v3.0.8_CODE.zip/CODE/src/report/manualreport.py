import json
from bs4 import BeautifulSoup
import os.path
import re
import sys

filepath = os.path.dirname(os.path.abspath(__file__))

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import manualcheck.constants as constants

"""def grabIP(param):
    ip_regexp = "\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}"
    matches = re.search(ip_regexp, param)
    curr_ip = ''
    if matches:
        curr_ip = matches.group(0)
    return curr_ip"""

def fileCheck(fn):
    try:
        open(fn, 'r')
        return 1
    except IOError:
        print('Error: ' + fn +' not found.')
        return 0

template = filepath+'/../../healthcheck-report.html'
fileCheck(template) 

with open(template) as inf:
    txt = inf.read()
    report = BeautifulSoup(txt, 'html.parser')

file1 = filepath+'/../data/manualcheck.json'
file2 = filepath+'/../data/tmp/manualresults/results.json'#sys.argv[1]

# print('Enter Manualcheck results file path(or leave blank for sample report): ')
# file2 = input()
if file2 == '':
    file2 = 'results-rollout.json'

fileCheck(file1)
fileCheck(file2)
with open(file1) as json_file:
    checks = json.load(json_file)
with open(file2) as json_file:
    results = json.load(json_file)

#print(file2 + ' is valid.')

# print("Please enter the path to the manual check logs here. (example: /Users/user/Downloads/results_multinode/LOGFILES/):")
# logPath = input()
logPath=filepath+'/../data/tmp/manualresults/LOGFILES/'#sys.argv[2]

oraDetails = report.findAll('td', class_ = 'oradetail')
count = len(oraDetails)
order = 1
h1s = report.findAll('h1', class_ = 'sub summary')
order += len(h1s)

full_data = checks['results']
data = []
for item in full_data:
    id = item['ID']
    if id in results:
        package = item
        package['status'] = results[id]
        data.append(package)

for item in data:
    title = report.new_tag('h1', attrs ={'class': 'sub summary', 'id': 'reco' + str(order)})
    title.append(str(order) + ': ' + item['ID'])

    summaryTitle = report.new_tag('h2', attrs = {'class': 'summary'})
    summaryTitle.append('Summary:')
    summary = report.new_tag('h2')
    summary.append(item['Long Description'])

    findingsTitle = report.new_tag('h2', attrs = {'class': 'summary'})
    findingsTitle.append('Findings:')
    findings = report.new_tag('h2')
    findings.append(item['Pseudo Code for Check'])

    recommendationTitle = report.new_tag('h2', attrs = {'class': 'summary'})
    recommendationTitle.append('Recommendation:')
    recommendation = report.new_tag('h2')
    recommendation.append(item['Impact'])
    recommendation.append(item['Mitigation Steps'])

    paramsTable = report.new_tag('table', attrs={'class': 'exa'})
    paramsHead = report.new_tag('thead')
    paramsHeadRow = report.new_tag('tr')
    paramsHeadName = report.new_tag('th')
    paramsHeadName.append('Node Name')
    paramsHeadStatus = report.new_tag('th')
    paramsHeadStatus.append('Status')
    paramsHeadRow.append(paramsHeadName)
    paramsHeadRow.append(paramsHeadStatus)
    paramsHead.append(paramsHeadRow)
    paramsTable.append(paramsHead)

    paramsBody = report.new_tag('tbody')
    params = item['status']
    recoStat = ''
    for vm in params:
        status = params[vm]

        paramsBodyRow = report.new_tag('tr')
        paramsBodyName = report.new_tag('td')
        paramsBodyStatus = report.new_tag('td')
        paramsDetailRow = report.new_tag('tr')
        paramsDetail = report.new_tag('td', attrs= {'class': 'oradetail', 'colspan': '2'})
        paramsLogWrapper = report.new_tag('pre', attrs = {'style': 'text-align: left; white-space: pre-wrap'})
        paramsLog = report.new_tag('code')

        paramsBodyName.append(vm)

        if status == constants.SUCCESS_STR:
            paramsButton = report.new_tag('button', attrs={'class': 'pass orabutton', 'onclick': 'toggleOraDetail('+str(count)+')'})
            recoStat = 'Pass'
        elif status == constants.FAILURE_STR: # or status == 'CRITICAL':
            paramsButton = report.new_tag('button', attrs={'class': 'fail orabutton', 'onclick': 'toggleOraDetail('+str(count)+')'})
            recoStat = 'Fail'
        elif status == constants.WARN_STR:
            paramsButton = report.new_tag('button', attrs={'class': 'warn orabutton', 'onclick': 'toggleOraDetail('+str(count)+')'})
            recoStat = 'Warning'
        elif status == constants.ERROR:
            paramsButton = report.new_tag('button', attrs={'class': 'ERROR orabutton', 'onclick': 'toggleOraDetail('+str(count)+')'})
            recoStat = 'ERROR'
        elif status == constants.NA_STR:
            paramsButton = report.new_tag('button', attrs={'class': 'na orabutton', 'onclick': 'toggleOraDetail('+str(count)+')'})
            recoStat = 'N/A'
        else:
            pass
        count += 1
        paramsButton.append(status)
        #paramsDetail.append('none')


        log = logPath+vm+'/'+item['ID']
        #print(log)
        if os.path.exists(log):
            f = open(log, 'r')
            logf = f.read() 
            f.close()
        else:
            logf = ""
        paramsLog.append('\n' + logf + '\n')
        #paramsDetail.append(logf)

        recoStatusTitle = report.new_tag('h2', attrs = {'class': 'summary'})
        recoStatusTitle.append('Status: ')
        if recoStat == 'Pass':
            recoStatus = report.new_tag('h2', attrs = {'class': 'recoStatus pass'})
            recoStatus.append('Pass')
        elif recoStat == 'Fail':
            recoStatus = report.new_tag('h2', attrs = {'class': 'recoStatus fail'})
            recoStatus.append('Fail')
        elif recoStat == 'Warning':
            recoStatus = report.new_tag('h2', attrs = {'class': 'recoStatus warn'})
            recoStatus.append('Warning')
        elif recoStat == 'ERROR':
            recoStatus = report.new_tag('h2', attrs = {'class': 'recoStatus ERROR'})
            recoStatus.append('ERROR')
        elif recoStat == 'N/A':
            recoStatus = report.new_tag('h2', attrs = {'class': 'recoStatus na'})
            recoStatus.append('N/A')
        else:
            pass


        paramsBodyStatus.append(paramsButton)
        paramsBodyRow.append(paramsBodyName)
        paramsBodyRow.append(paramsBodyStatus)
        paramsBody.append(paramsBodyRow)
        paramsLogWrapper.append(paramsLog)
        paramsDetail.append(paramsLogWrapper)
        paramsDetailRow.append(paramsDetail)
        paramsBody.append(paramsDetail)
    paramsTable.append(paramsBody)

    order += 1
    report.find(id='recommendations').append(title)
    report.find(id='recommendations').append(recoStatusTitle)
    report.find(id='recommendations').append(recoStatus)
    report.find(id='recommendations').append(summaryTitle)
    report.find(id='recommendations').append(summary)
    report.find(id='recommendations').append(findingsTitle)
    report.find(id='recommendations').append(findings)
    report.find(id='recommendations').append(recommendationTitle)
    report.find(id='recommendations').append(recommendation)
    report.find(id='recommendations').append(paramsTable)

##Write HTML to file
f = open(template, 'w')
f.write(report.prettify())
f.close()

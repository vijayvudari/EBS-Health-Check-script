import json
from bs4 import BeautifulSoup
import os.path

filepath = os.path.dirname(os.path.abspath(__file__))

def fileCheck(fn):
    try:
        open(fn, 'r')
        return 1
    except IOError:
        print('Error: ' + fn +' not found.')
        return 0

template = filepath+'/../../healthcheck-report.html'
file1 = filepath+'/../data/tmp/bde.json'
fileCheck(template)
fileCheck(file1)

with open(template) as inf:
    txt = inf.read()
    report = BeautifulSoup(txt, 'html.parser')

with open(file1) as json_file:
    bde = json.load(json_file)

##Title
#title_tag = report.new_tag("h1", attrs={'class': 'sub'})
order = 1
h1s = report.findAll('h1', class_ = 'sub summary')
order += len(h1s)
title_tag = report.new_tag('h1', attrs = {'class': 'sub summary', 'id': 'reco' + str(order)})
title_tag.append(str(order)+': Check of Relevant Parameters for Necessary Values')
#title_tag.append('Parameters:')
report.find(id="recommendations").append(title_tag)

##Summary
passes = 0
warnings = 0
criticals = 0
critData = {}
warnData = {}

#Summary logs
summary = {
    'Category': 'DB Configuration',
    'Application': 'EBS DB',
    'Component': 'Init parameters',
    'Short Description': 'Make sure the database init parameters are set correctly as they will directly influence the database performance.',
    'Long Description': 'EBS database init parameters, if not set correctly, will often impact the performance overall. Make sure to review the reference douments and remove all unnecessary underscore parameters.',
    'Priority': '1',
    'Impact': 'Refer the specific lists mentioned in the note attached as they describe database initialization parameters required for this specific release of the Oracle Database. Specific parameters should be added to the common database initialization parameters so that the final database initialization parameters file includes the common section plus the contents of this release-specific section. Make sure to set version specific parameters.',
    'Condition for Check': 'DB Init parameters',
    'Mitigation Steps': 'Review the output from the following notes and compare it with the standard recommmendations provided by EBS DEV in the reference note below - Oracle Support Document 396009.1 (Database Initialization Parameters for Oracle E-Business Suite Release 12) Oracle Support Document 174605.1 (bde_chk_cbo.sql - EBS initialization parameters - Healthcheck)'
}

##Initialization Parameters list
recommendations = bde['recommendations']
recoTable = report.new_tag("table", attrs={"class": "res"})
recoBody = report.new_tag("tbody")
rowHeader = report.new_tag('tr')
parameter = report.new_tag('th', attrs={'class': 'para'})
parameter.append('Parameter')
current = report.new_tag('th', attrs={'class': 'curr'})
current.append('Current Value')
required = report.new_tag('th', attrs={'class': 'val'})
required.append('Required Value')
button = report.new_tag('th', attrs={'class': 'check'})
rowHeader.append(parameter)
rowHeader.append(current)
rowHeader.append(required)
rowHeader.append(button)
recoBody.append(rowHeader)
customerParams = ['utl_file_dir', 'db_files', 'db_name', 'dml_locks', 'max_dump_file_size', 'log_buffer', 'db_block_checksum', 'job_queue_processes']
warningParams = ['log_archive_start', 'processes']

idx = 0
for item in recommendations:
    isPassed = False
    row = report.new_tag('tr')
    para = report.new_tag('td', attrs={'class': 'para'})
    curr = report.new_tag('td', attrs={'class': 'curr'})
    value = report.new_tag('td', attrs={'class': 'val'})
    check = report.new_tag('td', attrs={'class': 'check'})
    para.append(item['parameter'])
    curr.append(item['current value'])
    c = item['current value']
    if '(NOT SET)' in c:
        c = c.replace(' (NOT SET)', '')
    v = item['required value']
    if item['parameter'] in customerParams:
        value.append(item['current value'])
        v = item['current value']
    elif item['parameter'] == '_trace_files_public':
        value.append("FALSE")
    else:
        value.append(item['required value'])
    if item['parameter'] == 'processes' or item['parameter'] == 'sessions':
        minVal = int(v[:3])
        maxVal = int(v[4:])
        if int(c) >= minVal and int(c) <= maxVal:
            isPassed = True
    elif item['parameter'] == '_system_trig_enabled':
        if c.lower() != 'false':
            isPassed = True
    elif item['parameter'] == '_trace_files_public':
        if c.lower() != 'true':
            isPassed = True
    elif item['parameter'] == 'parallel_min_servers':
        isPassed = True
    elif item['parameter'] == 'parallel_max_servers':
        isPassed = True
    elif item['parameter'] == 'audit_trail':
        isPassed = True
    elif c.lower() in v.lower():
        isPassed = True

    if isPassed:
        passes += 1
        button = report.new_tag('button', attrs={'class': 'pass', 'onclick': 'toggleComment(' + str(idx) + ')'})
        button.append('O')
    elif item['parameter'] in warningParams:
        warnings += 1
        button = report.new_tag('button', attrs={'class': 'warn', 'onclick': 'toggleComment(' + str(idx) + ')'})
        button.append('W')
        warnData[item['parameter']] = v
    else:
        criticals += 1
        button = report.new_tag('button', attrs={'class': 'fail', 'onclick': 'toggleComment(' + str(idx) + ')'})
        button.append('X')
        critData[item['parameter']] = v

    #Comments
    commentRow = report.new_tag('tr')
    comment = report.new_tag('td', attrs={ 'colspan': '4', 'class': 'comment', 'display': 'none'})
    if item ['parameter'] == 'db_name':
        comment.append('DB_NAME specifies a database identifier of up to 8 characters. This parameter must be specified and must correspond to the name specified in the CREATE DATABASE statement.')
    if item ['parameter'] == 'control_files':
        comment.append('')
    if item ['parameter'] == 'db_block_size':
        comment.append('The range of this parameter is 2048-32768. DB_BLOCK_SIZE specifies (in bytes) the size of Oracle database blocks. Typical values are 4096 and 8192. The value of this parameter must be a multiple of the physical block size at the device level.')
    if item ['parameter'] == '_system_trig_enabled':
        comment.append('The default value of this parameter is true.')
    if item ['parameter'] == 'o7_dictionary_accessability':
        comment.append('O7_DICTIONARY_ACCESSIBILITY controls restrictions on SYSTEM privileges. If the parameter is set to true, access to objects in the SYS schema is allowed (Oracle7 behavior). The false setting ensures that system privileges that allow access to objects in "any schema" do not allow access to objects in the SYS schema.')
    if item ['parameter'] == 'nls_territory':
        comment.append('NLS_TERRITORY specifies the name of the territory whose conventions are to be followed for day and week numbering.')
    if item ['parameter'] == 'nls_date_format':
        comment.append('NLS_DATE_FORMAT specifies the default date format to use with the TO_CHAR and TO_DATE functions. The default value of this parameter is determined by NLS_TERRITORY.')
    if item ['parameter'] == 'nls_numeric_characters':
        comment.append('')
    if item ['parameter'] == 'nls_sort':
        comment.append('NLS_SORT specifies the collating sequence for character value comparison in various SQL operators and clauses, for example, ORDER BY, GROUP BY, comparison conditions (=, <>, <=, >=), IN, BETWEEN, LIKE, MIN/MAX, GREATEST/LEAST, and INSTR.')
    if item ['parameter'] == 'nls_comp':
        comment.append('')
    if item['parameter'] == 'audit_trail':
        comment.append('audit_trail can be set with the following values: (none) (os) (db) (db, extended) (xml) (xml, extended).')
        comment.append('Current Setting: DB. Directs audit records to the database audit trail (the SYS.AUD$ table), except for records that are always written to the operating system audit trail. Use this setting for a general database for manageability. If the database was started in read-only mode with AUDIT_TRAIL set to db, then Oracle Database internally sets AUDIT_TRAIL to os. Check the alert log for details.')
    if item['parameter'] == 'max_dump_file_size':
        comment.append('MAX_DUMP_FILE_SIZE specifies the maximum size of trace files (excluding the alert log). Change this limit if you are concerned that trace files may use too much space.')
    if item ['parameter'] == '_trace_files_public':
        comment.append('')
    if item ['parameter'] == 'processes':
        comment.append('PROCESSES specifies the maximum number of operating system user processes that can simultaneously connect to Oracle. Its value should allow for all background processes such as locks, job queue processes, and parallel execution processes. The default values of the SESSIONS and TRANSACTIONS parameters are derived from this parameter. Therefore, if you change the value of PROCESSES, you should evaluate whether to adjust the values of those derived parameters.')
    if item ['parameter'] == 'sessions':
        comment.append('The default value for this parameter is (1.5 * PROCESSES) + 22. SESSIONS specifies the maximum number of sessions that can be created in the system. Because every login requires a session, this parameter effectively determines the maximum number of concurrent users in the system. You should always set this parameter explicitly to a value equivalent to your estimate of the maximum number of concurrent users, plus the number of background processes, plus approximately 10 percent for recursive sessions.')
    if item ['parameter'] == 'db_files':
        comment.append('DB_FILES specifies the maximum number of database files that can be opened for this database. The maximum valid value is the maximum number of files, subject to operating system constraint, that will ever be specified for the database, including files to be added by ADD DATAFILE statements.')
    if item['parameter'] == 'dml_locks':
        comment.append('The value should equal the grand total of locks on tables currently referenced by all users.')
    if item ['parameter'] == 'cursor_sharing':
        comment.append('CURSOR_SHARING determines what kind of SQL statements can share the same cursors.')
    if item ['parameter'] == 'db_block_checking':
        comment.append('This parameter can have the following values: (off or false) (low) (medium) (full or true). Oracle checks a block by going through the data in the block, making sure it is logically self-consistent. Block checking can often prevent memory and data corruption. Block checking typically causes 1% to 10% overhead in most applications, depending on workload and the parameter value. Specific DML overhead may be higher. The more updates or inserts in a workload, the more expensive it is to turn on block checking. You should set DB_BLOCK_CHECKING to FULL if the performance overhead is acceptable.')
    if item['parameter'] == 'db_block_checksum':
        comment.append('db_block_checksum can be set with the following values: (off) (false) (typical) (true) (full)')
        comment.append('Oracle recommends that you set DB_BLOCK_CHECKSUM to TYPICAL.')
    if item ['parameter'] == 'log_checkpoint_timeout':
        comment.append('LOG_CHECKPOINT_TIMEOUT specifies (in seconds) the amount of time that has passed since the incremental checkpoint at the position where the last write to the redo log (sometimes called the tail of the log) occurred. This parameter also signifies that no buffer will remain dirty (in the cache) for more than integer seconds.')
    if item ['parameter'] == 'log_checkpoint_interval':
        comment.append('LOG_CHECKPOINT_INTERVAL specifies the frequency of checkpoints in terms of the number of redo log file blocks that can exist between an incremental checkpoint and the last block written to the redo log. This number refers to physical operating system blocks, not database blocks. Regardless of this value, a checkpoint always occurs when switching from one online redo log file to another. Therefore, if the value exceeds the actual redo log file size, checkpoints occur only when switching logs. Checkpoint frequency is one of the factors that influence the time required for the database to recover from an unexpected failure.')
    if item['parameter'] == 'log_buffer':
        comment.append('The default value of this parameter is 5MB to 32MB, depending on the SGA size and CPU count.')
        comment.append('The log buffer size depends on the number of redo strands in the system. One redo strand is allocated for every 16 CPUs and has a default size of 2 MB. Oracle allocates a minimum of 2 redo strands per instance. When the log buffer size is not specified, any remaining memory in the redo granules is given to the log buffer.')
    if item ['parameter'] == 'log_checkpoints_to_alert':
        comment.append('LOG_CHECKPOINTS_TO_ALERT lets you log your checkpoints to the alert log. Doing so is useful for determining whether checkpoints are occurring at the desired frequency.')
    if item ['parameter'] == 'cursor_space_for_time':
        comment.append('CURSOR_SPACE_FOR_TIME lets you use more space for cursors to save time. It affects both the shared SQL area and the clients private SQL area. Most users will not need to set this parameter because of the significantly enhanced concurrency modifications introduced in Oracle Database 10g Release 2 (10.2.0.2) and later.')
    if item ['parameter'] == 'utl_file_dir':
        comment.append('UTL_FILE_DIR lets you specify one or more directories that Oracle should use for PL/SQL file I/O. If you are specifying multiple directories, you must repeat the UTL_FILE_DIR parameter for each directory on separate lines of the initialization parameter file. All users can read or write to all files specified by this parameter. Therefore all PL/SQL users must be trusted with the information in the directories specified by this parameter.')
    if item['parameter'] == 'job_queue_processes':
        comment.append('job_queue_processes can be set with a range of values between 0-1000. If JOB_QUEUE_PROCESSES is set to a value in the range of 1 to 1000, then DBMS_JOB jobs and Oracle Scheduler jobs will run. The actual number of job slaves created for Oracle Scheduler jobs is auto-tuned by the Scheduler depending on several factors, including available resources, Resource Manager settings, and currently running jobs. However, the combined total number of job slaves running DBMS_JOB jobs and Oracle Scheduler jobs on an instance can never exceed the value of JOB_QUEUE_PROCESSES for that instance.')
    if item ['parameter'] == 'log_archive_start':
        comment.append('')
    if item['parameter'] == 'parallel_min_servers':
        comment.append('Parameter is set at the default value: CPU_COUNT * PARALLEL_THREADS_PER_CPU * 2.')
    if item['parameter'] == 'parallel_max_servers':
        comment.append('Parameter is set at the default value: PARALLEL_THREADS_PER_CPU * CPU_COUNT * concurrent_parallel_users * 5.')
    if item ['parameter'] == '_sort_elimination_cost_ratio':
        comment.append('The default value for this parameter is 0. The recommended value is 5.')
    if item ['parameter'] == '_like_with_bind_as_equality':
        comment.append('The default value for this parameter is FALSE. The recommended value is TRUE.')
    if item ['parameter'] == '_fast_full_scan_enabled	':
        comment.append('')
    if item ['parameter'] == 'cluster_database':
        comment.append('CLUSTER_DATABASE is an Oracle RAC parameter that specifies whether Oracle RAC is enabled.')
    if item ['parameter'] == 'instance_groups':
        comment.append('INSTANCE_GROUPS is an Oracle RAC parameter that you can specify only in parallel mode. Used with the PARALLEL_INSTANCE_GROUP parameter, it lets you restrict parallel query operations to a limited number of instances. This parameter specifies one or more instance groups and assigns the current instance to those groups. If one of the specified groups is also specified in the PARALLEL_INSTANCE_GROUP parameter, then Oracle allocates query processes for a parallel operation from this instance.')
    if item ['parameter'] == 'parallel_instance_group':
        comment.append('PARALLEL_INSTANCE_GROUP is an Oracle RAC parameter that you can specify in parallel mode only. Used in conjunction with services or with the INSTANCE_GROUPS parameter, it lets you restrict parallel query operations to a limited number of instances. Note that the INSTANCE_GROUPS parameter has been deprecated.')
    if item ['parameter'] == '':
        comment.append('')
    if isPassed:
        comment.append('This check has passed all requirements.')
    else:
        if item['parameter'] == 'processes':
            comment.append('Current value is out of range.')
        if 'instance_groups' in item['parameter']:
            comment.append('This is an Oracle RAC based parameter, setting a value is not required.')
        elif item['parameter'] == 'control_files':
            comment.append('At least three copies of control files are required. Current amount of copies is: 1.')
        else:
            comment.append('The current value is not set to its required value.')
    commentRow.append(comment)

    check.append(button)
    row.append(para)
    row.append(curr)
    row.append(value)
    row.append(check)
    recoBody.append(row)
    recoBody.append(commentRow)
    idx += 1
recoTable.append(recoBody)


##Release Parameters List
release = bde['release']
for item in release:
    row = report.new_tag('tr')
    para = report.new_tag('td', attrs={'class': 'para'})
    curr = report.new_tag('td', attrs={'class': 'curr'})
    value = report.new_tag('td', attrs={'class': 'val'})
    para.append(item['parameter'])
    curr.append(item['current value'])
    value.append(item['current value'])
    check = report.new_tag('td', attrs={'class': 'check'})
    button = report.new_tag('button',  attrs={'class': 'pass', 'onclick': 'toggleComment(' + str(idx) + ')'})
    passes += 1
    button.append('O')
    check.append(button)
    #req = report.new_tag('td')
    #req.append(item['required value'])

    #comments
    commentRow = report.new_tag('tr')
    comment = report.new_tag('td', attrs={ 'colspan': '4', 'class': 'comment', 'display': 'none'})
    if item ['parameter'] == 'optimizer_adaptive_features':
        comment.append('OPTIMIZER_ADAPTIVE_FEATURES enables or disables all of the adaptive optimizer features, including adaptive plan (adaptive join methods and bitmap pruning), automatic re-optimization, SQL plan directives, and adaptive distribution methods.')
    if item ['parameter'] == 'temp_undo_enabled':
        comment.append('TEMP_UNDO_ENABLED determines whether transactions within a particular session can have a temporary undo log. The default choice for database transactions has been to have a single undo log per transaction. This parameter, at the session level / system level scope, lets a transaction split its undo log into temporary undo log (for changes on temporary objects) and permanent undo log (for changes on persistent objects).')
    if item ['parameter'] == 'compatible':
        comment.append('COMPATIBLE enables you to use a new release of Oracle, while at the same time guaranteeing backward compatibility with an earlier release. This is helpful if it becomes necessary to revert to the earlier release.')
    if item ['parameter'] == 'diagnostic_dest':
        comment.append('As of Oracle Database 11g Release 1 (11.1), the diagnostics for each database instance are located in a dedicated directory, which can be specified through the DIAGNOSTIC_DEST initialization parameter. The structure of the directory specified by DIAGNOSTIC_DEST is as follows: <diagnostic_dest>/diag/rdbms/<dbname>/<instname>')
    if item ['parameter'] == 'sga_target':
        comment.append('SGA_TARGET specifies the total size of all SGA components. If SGA_TARGET is specified, then the following memory pools are automatically sized: Buffer cache (DB_CACHE_SIZE), Shared pool (SHARED_POOL_SIZE), Large pool (LARGE_POOL_SIZE), Java pool (JAVA_POOL_SIZE), Streams pool (STREAMS_POOL_SIZE)')
    if item ['parameter'] == 'shared_pool_size':
        comment.append('SHARED_POOL_SIZE specifies (in bytes) the size of the shared pool. The shared pool contains shared cursors, stored procedures, control structures, and other structures. If you set PARALLEL_AUTOMATIC_TUNING to false, then Oracle also allocates parallel execution message buffers from the shared pool. Larger values improve performance in multiuser systems. Smaller values use less memory.')
    if item ['parameter'] == 'shared_pool_reserved_size':
        comment.append('SHARED_POOL_RESERVED_SIZE specifies (in bytes) the shared pool space that is reserved for large contiguous requests for shared pool memory. You can use this parameter to avoid performance degradation in the shared pool in situations where pool fragmentation forces Oracle to search for and free chunks of unused pool to satisfy the current request.')
    if item ['parameter'] == 'nls_length_semantics':
        comment.append('The session-level value of NLS_LENGTH_SEMANTICS specifies the default length semantics to use for VARCHAR2 and CHAR table columns, user-defined object attributes, and PL/SQL variables in database objects created in the session. This default may be overridden by the explicit length semantics qualifiers BYTE and CHAR in column, attribute, and variable definitions.')
    if item ['parameter'] == 'undo_management':
        comment.append('UNDO_MANAGEMENT specifies which undo space management mode the system should use. When set to AUTO, the instance starts in automatic undo management mode. In manual undo management mode, undo space is allocated externally as rollback segments.')
    if item ['parameter'] == 'undo_tablespace':
        comment.append('UNDO_TABLESPACE specifies the undo tablespace to be used when an instance starts. If this parameter is specified when the instance is in manual undo management mode, then an error will occur and startup will fail.')
    if item ['parameter'] == 'pga_aggregate_target':
        comment.append('PGA_AGGREGATE_TARGET specifies the target aggregate PGA memory available to all server processes attached to the instance. To set a hard limit for aggregate PGA memory, use the PGA_AGGREGATE_LIMIT parameter.')
    if item ['parameter'] == 'workarea_size_policy':
        comment.append('WORKAREA_SIZE_POLICY specifies the policy for sizing work areas. This parameter controls the mode in which working areas are tuned.')
    if item ['parameter'] == 'olap_page_pool_size':
        comment.append('OLAP_PAGE_POOL_SIZE specifies (in bytes) the size of the OLAP page pool.')
    if item ['parameter'] == 'open_cursors':
        comment.append('OPEN_CURSORS specifies the maximum number of open cursors (handles to private SQL areas) a session can have at once. You can use this parameter to prevent a session from opening an excessive number of cursors.')
    if item ['parameter'] == 'session_cached_cursors':
        comment.append('SESSION_CACHED_CURSORS specifies the number of session cursors to cache. Repeated parse calls of the same SQL (including recursive SQL) or PL/SQL statement cause the session cursor for that statement to be moved into the session cursor cache. Oracle uses a least recently used algorithm to remove entries in the session cursor cache to make room for new entries when needed.')
    if item ['parameter'] == 'plsql_code_type':
        comment.append('PLSQL_CODE_TYPE specifies the compilation mode for PL/SQL library units. INTERPRETED: PL/SQL library units will be compiled to PL/SQL bytecode format. Such modules are executed by the PL/SQL interpreter engine. NATIVE:PL/SQL library units (with the possible exception of top-level anonymous PL/SQL blocks) will be compiled to native (machine) code. Such modules will be executed natively without incurring any interpreter overhead.')
    if item ['parameter'] == '_b_tree_bitmap_plans':
        comment.append('')
    if item ['parameter'] == 'optimizer_secure_view_merging':
        comment.append('OPTIMIZER_SECURE_VIEW_MERGING enables the optimizer to use view merging to improve query performance without performing the checks that would otherwise be performed to ensure that view merging does not violate any security intentions of the view creator.')
    if item ['parameter'] == '_optimizer_autostats_job':
        comment.append('')
    if item ['parameter'] == 'parallel_force_local':
        comment.append('PARALLEL_FORCE_LOCAL controls parallel execution in an Oracle RAC environment. By default, the parallel server processes selected to execute a SQL statement can operate on any or all Oracle RAC nodes in the cluster. By setting PARALLEL_FORCE_LOCAL to true, the parallel server processes are restricted so that they can only operate on the same Oracle RAC node where the query coordinator resides (the node on which the SQL statement was executed).')
    if item ['parameter'] == 'pga_aggregate_limit':
        comment.append('PGA_AGGREGATE_LIMIT specifies a limit on the aggregate PGA memory consumed by the instance. There is no difference in behavior between PGA_AGGREGATE_LIMIT being explicitly set or being set to the default.')
    if item ['parameter'] == 'sec_case_sensitive_logon':
        comment.append('SEC_CASE_SENSITIVE_LOGON enables or disables password case sensitivity in the database. TRUE: Database logon passwords are case sensitive. FALSE: Database logon passwords are not case sensitive.')
    if item ['parameter'] == 'aq_tm_processes':
        comment.append('AQ_TM_PROCESSES controls time monitoring on queue messages and controls processing of messages with delay and expiration properties specified.You do not need to specify a value for this parameter because Oracle Database automatically determines the number of processes and autotunes them, as necessary. Therefore, Oracle highly recommends that you leave the AQ_TM_PROCESSES parameter unspecified and let the system autotune.')
    if item ['parameter'] == 'service_names':
        comment.append('SERVICE_NAMES specifies one or more names by which clients can connect to the instance. The instance registers its service names with the listener. When a client requests a service, the listener determines which instances offer the requested service and routes the client to the appropriate instance. You can specify multiple service names to distinguish among different uses of the same database. For example: SERVICE_NAMES = sales.example.com, widgetsales.example.com')
    if item ['parameter'] == 'recyclebin':
        comment.append('RECYCLEBIN is used to control whether the Flashback Drop capability is turned on or off. If the parameter is set to off, then dropped tables do not go into the recycle bin. If this parameter is set to on, then dropped tables go into the recycle bin and can be recovered.')
    if item ['parameter'] == '':
        comment.append('')
    if isPassed:
        comment.append('This check has passed all requirements.')
    else:
        comment.append('The current value is not set to its required value.')
    commentRow.append(comment)

    row.append(para)
    row.append(curr)
    row.append(value)
    row.append(check)
    #row.append(req)
    recoBody.append(row)
    recoBody.append(commentRow)
    idx += 1


##Removal List
removals = bde['removals']
for item in removals:
    row = report.new_tag('tr')
    para = report.new_tag('td', attrs={'class': 'para'})
    para.append(item['parameter'])
    curr = report.new_tag('td', attrs={'class': 'curr'})
    curr.append(item['current value'])
    value = report.new_tag('td', attrs={'class': 'val'})
    value.append('Oracle recommends that this parameter be removed or set to its default value.')
    check = report.new_tag('td', attrs={'class': 'check'})
    button = report.new_tag('button',  attrs={'class': 'pass'})
    passes += 1
    button.append('O')
    check.append(button)
    row.append(para)
    row.append(curr)
    row.append(value)
    row.append(check)
    recoBody.append(row)

    #comments

##Custom Parameters List:
custom = bde['custom']
rowHeader = report.new_tag('tr')
parameter = report.new_tag('th')
parameter.append('Parameter')
current = report.new_tag('th')
current.append('Current Value')

for item in custom:
    row = report.new_tag('tr')
    para = report.new_tag('td', attrs={'class': 'para'})
    para.append(item['parameter'])
    curr = report.new_tag('td', attrs={'class': 'curr'})
    curr.append(item['current value'])
    value = report.new_tag('td', attrs={'class': 'val'})
    value.append('Oracle recommends that this parameter be removed or set to its default value.')
    check = report.new_tag('td', attrs={'class': 'check'})
    button = report.new_tag('button',  attrs={'class': 'pass'})
    passes += 1
    button.append('O')
    check.append(button)
    #req = report.new_tag('td')
    #req.append(item['required value'])
    row.append(para)
    row.append(curr)
    row.append(value)
    row.append(check)
    #row.append(req)
    recoBody.append(row)

totals = passes + warnings + criticals
##Status Summary
recoStatusTitle = report.new_tag('h2', attrs={"class": "summary"})
recoStatusTitle.append('Status:')
if passes == totals:
    recoStatus = report.new_tag('h2', attrs={"class": "recoStatus pass"})
    recoStatus.append('Pass')
elif passes > totals/2:
    recoStatus = report.new_tag('h2', attrs={"class": "recoStatus warn"})
    recoStatus.append('Warning')
else:
    recoStatus = report.new_tag('h2', attrs={"class": "recoStatus fail"})
    recoStatus.append('Fail')

##Summary
summ_title = report.new_tag('h2', attrs={"class": "summary"})
summ_title.append('Summary:')
summ_para = report.new_tag('h2')
summ_para.append(summary['Short Description'])
summ_para.append(summary['Long Description'])
findings_title = report.new_tag('h2', attrs={"class": "summary"})
findings_title.append('Findings:')
summ_findings = report.new_tag('h2')
summ_crits = report.new_tag("table", attrs={"class": "findings"})
summ_critsBody = report.new_tag('tbody')
crit_findings = report.new_tag('h2')
summ_warns = report.new_tag("table", attrs={"class": "findings"})
summ_warnsBody = report.new_tag('tbody')
warn_findings = report.new_tag('h2')
if criticals > 0 or warnings > 0:
    summ_findings.append('The following parameters have been identified as different from EBS recommended settings')
    if criticals > 0:
        crit_findings.append('Critical Parameters in a Failed State')
        rowHeader = report.new_tag('tr')
        parameter = report.new_tag('th', attrs={'class': 'para'})
        parameter.append('Parameter')
        required = report.new_tag('th', attrs= {'class': 'val'})
        required.append('Recommended Setting')
        rowHeader.append(parameter)
        rowHeader.append(required)
        summ_critsBody.append(rowHeader)
        for x in critData:
            rowData = report.new_tag('tr')
            para = report.new_tag('td', attrs={'class': 'para'})
            req = report.new_tag('td', attrs={'class': 'val'})
            para.append(x)
            req.append(critData[x])
            rowData.append(para)
            rowData.append(req)
            summ_critsBody.append(rowData)
    if warnings > 0:
        warn_findings.append('Critical Parameters in a Warning State')
        rowHeader = report.new_tag('tr')
        parameter = report.new_tag('th', attrs={'class': 'para'})
        parameter.append('Parameter')
        required = report.new_tag('th', attrs= {'class': 'val'})
        required.append('Recommended Setting')
        rowHeader.append(parameter)
        rowHeader.append(required)
        summ_warnsBody.append(rowHeader)
        for x in warnData:
            rowData = report.new_tag('tr')
            para = report.new_tag('td', attrs={'class': 'para'})
            req = report.new_tag('td', attrs={'class': 'val'})
            para.append(x)
            req.append(warnData[x])
            rowData.append(para)
            rowData.append(req)
            summ_warnsBody.append(rowData)
summ_crits.append(summ_critsBody)
summ_warns.append(summ_warnsBody)

#Recommendations
reco_title = report.new_tag('h2', attrs={"class": "summary"})
reco_title.append('Recommendation:')
summ_reco = report.new_tag('h2')
summ_reco.append(summary['Impact'])
summ_reco.append(report.new_tag('br'))
summ_reco.append(report.new_tag('br'))
summ_reco.append(summary['Mitigation Steps'])

summ_tag = report.new_tag('h2')
summ_tag.append('Out of a total of ' + str(totals) + ' parameters: ' + str(passes) + ' passed, ' + str(warnings) + ' warnings, ' + str(criticals) + ' failed.')


##Appending content to html template
report.find(id="recommendations").append(recoStatusTitle)
report.find(id="recommendations").append(recoStatus)
report.find(id="recommendations").append(summ_title)
report.find(id="recommendations").append(summ_tag)
report.find(id="recommendations").append(summ_para)
report.find(id="recommendations").append(findings_title)
report.find(id="recommendations").append(summ_findings)
report.find(id="recommendations").append(crit_findings)
report.find(id="recommendations").append(summ_crits)
report.find(id="recommendations").append(warn_findings)
report.find(id="recommendations").append(summ_warns)
report.find(id="recommendations").append(reco_title)
report.find(id="recommendations").append(summ_reco)


##Toggle Buttons
all_title = report.new_tag('h2', attrs={"class": "summary"})
all_title.append('All Parameters:')
#report.find(id="recommendations").append(all_title)
toggleCrit = report.new_tag("button", attrs= {'class': 'toggle', 'onclick': 'toggle("")'})
toggleCrit.append('pass')
#report.find(id="recommendations").append(toggleCrit)

toggleWarn = report.new_tag("button", attrs= {'class': 'toggle', 'onclick': 'toggle("warn")'})
toggleWarn.append('warnings')
#report.find(id="recommendations").append(toggleWarn)

toggleAll = report.new_tag("button", attrs= {'class': 'toggle', 'onclick': 'toggle("fail")'})
toggleAll.append('fail')
#report.find(id="recommendations").append(toggleAll)

##Table parsing
recoTable.append(recoBody)
report.find(id="recommendations").append(recoTable)
f = open(filepath+'/../../healthcheck-report.html', 'w')
f.write(report.prettify())
f.close()
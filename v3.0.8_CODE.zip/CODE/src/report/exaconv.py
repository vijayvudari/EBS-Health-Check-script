import json
import os.path
import sys

filepath = os.path.dirname(os.path.abspath(__file__)) 
def fileCheck(fn):
    try:
        open(fn, 'r')
        return 1
    except IOError:
        print('Error: ' + fn +' not found.')
        return 0

# print('Enter Oracheck results file path(or leave blank for sample report): ')
# file1 = input()
file1=sys.argv[1]

# print('Enter Oracheck recommendations file path(or leave blank for sample report): ')
# file2 = input()
file2=sys.argv[2]
fileCheck(file1)
fileCheck(file2)

with open(file1) as json_file:
    results = json.load(json_file)

with open(file2) as json_file:
    recommendations = json.load(json_file)

output = filepath+'/../data/tmp/ora.json'
#results = results['results']
#recommendations = recommendations['results']
data = {}
count = 0

# the following checks are omitted from the report
omit_exachkIDs = ["DCAC61E06536FEDAE053D298EB0A9812"]

def cleanDetails(detail, name):
    if name == '':
        return detail
    subsetIdx = [i for i in range(len(detail)) if detail.startswith('DATA FROM', i)]
    subset = ''
    if len(subsetIdx) < 2:
        subset = detail
    else:
        for i in range(1,len(subsetIdx)):
            a = subsetIdx[i-1]
            b = subsetIdx[i]
            if name in detail[a:b]:
                subset = detail[a:b]
                break
    return subset
    
##Formatting JSON exacheck data into required data structures
for result in results:
    try:
        exaID = result['exachkID']
    except:
        continue
    if exaID in omit_exachkIDs:
        continue
    parameter = '' if 'NodeName' not in result else result['NodeName']
    if parameter == '':
        parameter = '' if 'DBName' not in result else result['DBName']
    status = '' if 'exachkStatus' not in result else result['exachkStatus']
    statusCode = '' if 'exachkStatusCode' not in result else result['exachkStatusCode']
    instance = '' if 'InstanceName' not in result else result['InstanceName']
    target = '' if 'exachkTargetType' not in result else result['exachkTargetType']
    details = '' if 'exachkMsgDetail' not in result else result['exachkMsgDetail']
    instName = '' if len(instance) == 0 else instance[:len(instance)-1] 
    #details = cleanDetails(details, instName)
    newParam = {
        'parameter': parameter,
        'target': target,
        'status': status,
        'statusCode': statusCode,
        'instance': instance,
        'details': details
    }
    if exaID not in data:
        message = '' if 'exachkmessage' not in result else result['exachkmessage']
        exaType = '' if 'exachkType' not in result else result['exachkType']
        alert = '' if 'exachkAlertType' not in result else result['exachkAlertType']
        name = '' if 'exachkName' not in result else result['exachkName']
        node = '' if 'NodeName' not in result else result['NodeName']
        if node == '':
            node = '' if 'DBName' not in result else result['DBName']
        recommendation = ''
        for item in recommendations:
            if 'exachkID' in item and exaID == item['exachkID']:
                recommendation = item['Recommendation']
        newCol = {
            'name': name,
            'type': exaType,
            'message': message,
            'recommendation': recommendation,
            'node': node,
            'alert': alert,
            'parameters': []
        }
        data[exaID] = newCol
    data[exaID]['parameters'].append(newParam)

f = open(output, 'w')
json.dump(data, f, indent=4)
f.close()

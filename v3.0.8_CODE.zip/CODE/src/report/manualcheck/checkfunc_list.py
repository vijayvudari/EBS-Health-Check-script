from checkfuncs import *

checks = [
  { #1
    "name": "CONFIG_EBS_CONCURRENT_MGR_1",
    "function": CONFIG_EBS_CONCURRENT_MGR_1,
    "type": "application",
    "params": {
      "SH": ["S_BATCH_STATUS", "FIND_LIBR"]
    }
  },
  { #2
    "name": "KNOWN_ISSUES_EBS_FILE_SYSTEM_1",
    "function": KNOWN_ISSUES_EBS_FILE_SYSTEM_1,
    "type": "application",
    "params": {
      "SH": ["CHECK_APPLLDM"]
    }
  },
  { #4
    "name": "OPER_READINESS_EBS_BACKUP_1",
    "function": OPER_READINESS_EBS_BACKUP_1,
    "type": "database",
    "params": {
      "SH": ["CRONTAB_BKUP_START"]
    }
  },
  { #5
    "name": "CONFIG_EBS_APACHE_1",
    "function": CONFIG_EBS_APACHE_1,
    "type": "application",
    "params": {
      "SH": ["CHECK_PIDS_DIR"]
    }
  },
  { #7
    "name": "CONFIG_EBS_OACORE_PERF_1",
    "function": CONFIG_EBS_OACORE_PERF_1,
    "type": "application",
    "params": {
      "SH": ["S_OACORE_NPROCS", "CHECK_OACORE"]
    }
  },
  { #10
    "name": "CONFIG_EBS_OACORE_PERF_2",
    "function": CONFIG_EBS_OACORE_PERF_2,
    "type": "application",
    "params": {
      "SH": ["CHECK_RESPONSE_XMS"]
    }
  },
  { #11
    "name": "CONFIG_EBS_CONC_LOG",
    "function": CONFIG_EBS_CONC_LOG,
    "type": "application",
    "params": {
      "SH": ["CHECK_SIZE_REPORTS"]
    }
  },
  { #12
    "name": "CONFIG_EBS_OPP_MGR",
    "function": CONFIG_EBS_OPP_MGR,
    "type": "application", # appdb
    "params": {
      "SQL": ["PULL_OPP_SIZE"]
    }
  },
  { #21
    "name": "CONFIG_WORKFLOW_PURGE",
    "function": CONFIG_WORKFLOW_PURGE,
    "type": "application", # appdb
    "params": {
      "SQL": ["WORKFLOW_PURGE_CLOSED", "WORKFLOW_PURGE_ORPH_UNREF"]
    }
  },
  { #22
    "name": "CONFIG_WORKFLOW_STUCK",
    "function": CONFIG_WORKFLOW_STUCK,
    "type": "application", # appdb
    "params": {
      "SQL": ["WORKFLOW_BKG_STUCK"]
    }
  },
  { #23
    "name": "CONFIG_WORKFLOW_RETENTION",
    "function": CONFIG_WORKFLOW_RETENTION,
    "type": "application", # appdb
    "params": {
      "SQL": ["WORKFLOW_RETENTION"]
    }
  },
  { #24
    "name": "CONFIG_PROFILE_LOGGING",
    "function": CONFIG_PROFILE_LOGGING,
    "type": "application", # appdb
    "params": {
      "SQL": ["LOGGING_BUG"]
    }
  },
  { #26
    "name": "CONFIG_DB_CONN",
    "function": CONFIG_DB_CONN,
    "type": "application", # appdb
    "params": {
      "SH": ["ECHO_TWO_TASK", "TOOLS_TWO_TASK", "CP_TWO_TASK", "S_TWO_TASK", "CHECK_JDBC_URL"],
      "SQL": ["SHO_CLUSTER"]
    }
  },
  { #28
    "name": "CONFIG_TDE",
    "function": CONFIG_TDE,
    "type": "application", # appdb
    "params": {
      "SQL": ["TDE_ENCRYPTION"]
    }
  },
  { #38
    "name": "CONFIG_DB_PARAM_BKP_1",
    "function": CONFIG_DB_PARAM_BKP_1,
    "type": "application", # appdb
    "params": {
      "SQL": ["GET_RECO", "SHO_DB_RECOVERY_SIZE"]
    }
  },
  { #39
    "name": "CONFIG_DB_PARAM_BKP_2",
    "function": CONFIG_DB_PARAM_BKP_2,
    "type": "application", # appdb
    "params": {
      "SQL": ["SHO_DB_RECOVERY", "SHO_DB_LOG_DEST"]
    }
  },
  { #40
    "name": "CONFIG_DB_SQLNET",
    "function": CONFIG_DB_SQLNET,
    "type": "database",
    "params": {
      "SH": ["ENCRYPTION_WALLET"]
    }
  },
  { #41
    "name": "EBS_CONC_REQ_1",
    "function": EBS_CONC_REQ_1,
    "type": "application",
    "params": {
      "SQL": ["FNDWFPR"]
    }
  },
  { #42
    "name": "EBS_CONC_REQ_2",
    "function": EBS_CONC_REQ_2,
    "type": "application",
    "params": {
      "SQL": ["FNDWFBES_CONTROL_QUEUE_CLEANUP"]
    }
  },
  { #43
    "name": "EBS_CONC_REQ_3",
    "function": EBS_CONC_REQ_3,
    "type": "application",
    "params": {
      "SQL": ["FNDSCPRG"]
    }
  },
  { #44
    "name": "EBS_CONC_REQ_4",
    "function": EBS_CONC_REQ_4,
    "type": "application",
    "params": {
      "SQL": ["FNDLGPRG"]
    }
  },
  { #45
    "name": "EBS_CONC_REQ_5",
    "function": EBS_CONC_REQ_5,
    "type": "application", # appdb
    "params": {
      "SQL": ["MSCATPPURG"]
    }
  },
  { #46
    "name": "EBS_CONC_REQ_6",
    "function": EBS_CONC_REQ_6,
    "type": "application", # appdb
    "params": {
      "SQL": ["FNDDLTMP"]
    }
  },
  { #47
    "name": "EBS_CONC_REQ_7",
    "function": EBS_CONC_REQ_7,
    "type": "application", # appdb
    "params": {
      "SQL": ["FNDGFMPR"]
    }
  },
  { #48
    "name": "EBS_CONC_REQ_8",
    "function": EBS_CONC_REQ_8,
    "type": "application", # appdb
    "params": {
      "SQL": ["FNDWFBG"]
    }
  },
  { #50
    "name": "EBS_CONC_REQ_10",
    "function": EBS_CONC_REQ_10,
    "type": "application", # appdb
    "params": {
      "SQL": ["RGOPTM"]
    }
  },
  { #51
    "name": "EBS_CONC_REQ_11",
    "function": EBS_CONC_REQ_11,
    "type": "application", # appdb
    "params": {
      "SQL": ["GSCHSTATCHECK"]
    }
  },
  { #53
    "name": "EBS_CONC_REQ_13",
    "function": EBS_CONC_REQ_13,
    "type": "application", # appdb
    "params": {
      "SQL": ["PROGMST"]
    }
  },
  { #56
    "name": "CONFIG_DB_PARA_PERF_1",
    "function": CONFIG_DB_PARA_PERF_1,
    "type": "application", # appdb
    "params": {
      "SQL": ["SHO_FSYS_OPTIONS"]
    }
  },
  { #63
    "name": "ADOP_PATCHING_EBS_OLD_SESSION_CLEANUP",
    "function": ADOP_PATCHING_EBS_OLD_SESSION_CLEANUP,
    "type": "application", # appdb
    "params": {
      "SQL": ["ADOPEDITION"]
    }
  },
  { #64
    "name": "WEBLOGIC_EBS_STARTUP_ISSUES",
    "function": WEBLOGIC_EBS_STARTUP_ISSUES,
    "type": "application",
    "params": {
      "SH": ["LS_DEV_RANDOM", "GREP_SECURE_RANDOM", "GREP_JAVA_SECURITY"]
    }
  },
  { #65
    "name": "EBS_MONITORING",
    "function": EBS_MONITORING,
    "type": "application",
    "params": {
      "SH": ["OSWATCHER"]
    }
  },
  { #66
    "name": "JRE_EBS_SECURITY",
    "function": JRE_EBS_SECURITY,
    "type": "application",
    "params": {
      "SH": ["S_FORMS_LAUNCH_METHOD"],
      "SQL": ["PROFILE_FND_ENABLE_JWS", "PROFILE_ICX_FORMS_LAUNCHER"]
    }
  }
]
#########################################################################################
######################################### TESTS #########################################
#########################################################################################

import xmltodict
import re

# file imports
import constants
from helperfuncs import print_debug

"""
params = {
  "VM_NAME": {
    "logfile": File(),
    "SH_RESPONSES": {
      "SH_ID": {
        "command": "",
        "result": ["one", "response", "per", "line"],
        "log": ""
      }, ...
    },
    "SQL_RESPONSES": {
      "SQL_ID": {
        "command": "",
        "result": [{"COLNAME": "", ...}],
        "log": ""
      }, ...
    },
    "EBS_VERSION": "",
    "DB_VERSION": ""
  }, ...
}
"""

#1
def CONFIG_EBS_CONCURRENT_MGR_1(params):
  vm_count = len(params)
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  if vm_count < 2: # check if VM count is less than 2
    s = "<<< There are less than 2 Application Nodes, check is not applied. >>>\n"
    print_debug(s)
    for vm in params:
      logfiles[vm].write(s)
    return {vm: constants.SKIP_STR for vm in params}

  n_enabled = 0
  n_threads = 0
  for vm in params:
    logfile = logfiles[vm]
    try: # get params
      s_batch_status = params[vm]["SH_RESPONSES"]["S_BATCH_STATUS"]
      find_libr = params[vm]["SH_RESPONSES"]["FIND_LIBR"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: s_batch_status, find_libr\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      continue

    try:
      logfile.write(s_batch_status["log"])
      logfile.write(find_libr["log"])
    except:
      print_debug(f"Warning: some logs could not be written for node {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # context check
      res = xmltodict.parse(s_batch_status["result"][0])["oa_service_group_status"]["#text"]
      logfile.write(f">>> LOGGING VARIABLE:\n  s_batch_status: {res}\n")
      if not res == "enabled":
        logfile.write("<<< Oa_service_group concurrency not established... >>>\n")
      else:
        n_enabled += 1
    except Exception as e:
      s = f"  Encountered an error while running context check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)

    try: # thread check
      res = int(find_libr["result"][0])
      logfile.write(f">>> LOGGING VARIABLE:\n  find_libr count: {res}\n")
      if res >= 1:
        n_threads += 1
    except Exception as e:
      s = f"  Encountered an error while running thread check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)

  result = constants.SUCCESS_STR if n_enabled >= 2 and n_threads >= 2 else constants.FAILURE_STR
  return {vm: result for vm in params} # same result for all nodes

#2
def KNOWN_ISSUES_EBS_FILE_SYSTEM_1(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    applldm_check = False
    try: # get params
      ebs_version = params[vm]["EBS_VERSION"]
      check_applldm = params[vm]["SH_RESPONSES"]["CHECK_APPLLDM"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: ebs_version, check_applldm\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      continue

    try:
      logfile.write(check_applldm["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # version check
      logfile.write(f"<<< Version {ebs_version} detected. >>>\n")
      if ebs_version[:4] != "12.2":
        logfile.write(f"<<< Check applies to 12.2.x only. >>>\n")
        results[vm] = constants.SKIP_STR
        continue
    except Exception as e:
      s = f"  Encountered an error while running version check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try: # applldm check
      res = check_applldm["result"][0]
      # remove the ANSI escape sequences. source: https://stackoverflow.com/questions/14693701/how-can-i-remove-the-ansi-escape-sequences-from-a-string-in-python
      try:
        ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
        res = ansi_escape.sub("", res) # remove all escape sequences
        res = xmltodict.parse(res)["APPLLDM"]["#text"]
        logfile.write(f">>> LOGGING VARIABLE:\n  applldm: {res}\n")
      except:
        logfile.write(f"!!! Unable to remove ANSI escape sequences from \"{check_applldm['result'][0]}\"\n")
      applldm_check = res not in ["", "single"]
    except Exception as e:
      s = f"  Encountered an error while running applldm check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if applldm_check else constants.FAILURE_STR

  return results

#4
def OPER_READINESS_EBS_BACKUP_1(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    crontab_check = False
    try: # get params
      crontab_bkup_start = params[vm]["SH_RESPONSES"]["CRONTAB_BKUP_START"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: crontab_bkup_start\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(crontab_bkup_start["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # crontab check
      res = int(crontab_bkup_start["result"][0])
      logfile.write(f">>> LOGGING VARIABLE:\n  crontab backup count: {res}\n")
      crontab_check = res >= 1
    except Exception as e:
      s = f"  Encountered an error while running crontab check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if crontab_check else constants.WARN_STR

  return results

#5
def CONFIG_EBS_APACHE_1(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    mount_check = False
    try: # get params
      check_pids_dir = params[vm]["SH_RESPONSES"]["CHECK_PIDS_DIR"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: s_pids_dir check_pids_dir\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(check_pids_dir["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # mount check
      res = int(check_pids_dir["result"][0])
      logfile.write(f">>> LOGGING VARIABLE:\n  mount count: {res}\n")
      mount_check = res == 0
    except Exception as e:
      s = f"  Encountered an error while running mount check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if mount_check else constants.FAILURE_STR

  return results

#7
def CONFIG_EBS_OACORE_PERF_1(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    oacore_check = False
    try: # get params
      ebs_version = params[vm]["EBS_VERSION"]
      s_oacore_nprocs = params[vm]["SH_RESPONSES"]["S_OACORE_NPROCS"]
      check_oacore = params[vm]["SH_RESPONSES"]["CHECK_OACORE"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: ebs_version s_oacore_nprocs check_oacore\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(s_oacore_nprocs["log"])
      logfile.write(check_oacore["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # version check
      logfile.write(f"<<< Version {ebs_version} detected. >>>\n")
      if ebs_version != "12.1.3" and ebs_version[:4] != "12.2":
        logfile.write("<<< Check applies to 12.2.x or 12.1.3 only. >>>\n")
        results[vm] = constants.NA_STR
        continue
    except Exception as e:
      s = f"  Encountered an error while running version check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try: # oacore check
      oacore_obj = check_oacore
      oacore_name = "oa_managed_server_names"
      if ebs_version == "12.1.3":
        oacore_obj = s_oacore_nprocs
        oacore_name = "oacore_nprocs"
      res = oacore_obj["result"][0]
      # remove the ANSI escape sequences. source: https://stackoverflow.com/questions/14693701/how-can-i-remove-the-ansi-escape-sequences-from-a-string-in-python
      try:
        ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
        res = ansi_escape.sub("", res) # remove all escape sequences
        res = xmltodict.parse(res)[oacore_name]["#text"]
        logfile.write(f">>> LOGGING VARIABLE:\n  {oacore_name}: {res}\n")
      except:
        logfile.write(f"!!! Unable to remove ANSI escape sequences from \"{oacore_obj['result'][0]}\"\n")
      if ebs_version == "12.1.3":
        oacore_check = int(res) > 1
      else:
        oacore_check = len(res) > 1
    except Exception as e:
      s = f"  Encountered an error while running mount check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if oacore_check else constants.FAILURE_STR

  return results

#10
def CONFIG_EBS_OACORE_PERF_2(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    xms_check = False
    try: # get params
      check_response_xms = params[vm]["SH_RESPONSES"]["CHECK_RESPONSE_XMS"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: check_response_xms\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(check_response_xms["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # xms/xmx check
      res = check_response_xms["result"]
      if len(res) != 0:
        parsed = []
        for item in res:
          parsed.append(xmltodict.parse(item))
        argdicts = [{} for i in range(len(parsed))]
        targets = ["Xms", "Xmx"]
        targetDict = {}
        for i in range(len(parsed)):
          rawStr = parsed[i]['arguments'].split(" ")
          for entry in rawStr:
            shiftSplit = entry[1:].split("=")
            target = shiftSplit[0][:3]
            if target in targets:
              targetDict[target] = int(shiftSplit[0][3:-1])
            if len(shiftSplit) == 1:
              argdicts[i][shiftSplit[0]] = ""
            else:
              argdicts[i][shiftSplit[0]] = shiftSplit[1]
        xms = targetDict["Xms"]
        xmx = targetDict["Xmx"]
        logfile.write(f">>> LOGGING VARIABLES:\n  xms: {xms}\n  xmx: {xmx}\n")
        xms_check = xms >= 2048 and xmx >= 2048
      else:
        logfile.write("!!! No results returned.\n")
    except Exception as e:
      s = f"  Encountered an error while running xms/xmx check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if xms_check else constants.FAILURE_STR

  return results

#11
def CONFIG_EBS_CONC_LOG(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    report_check = False
    try: # get params
      check_size_reports = params[vm]["SH_RESPONSES"]["CHECK_SIZE_REPORTS"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: check_size_reports\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(check_size_reports["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # report check
      res = int(check_size_reports["result"][0].split(" ")[4])
      logfile.write(f">>> LOGGING VARIABLE:\n  size: {res}\n")
      report_check = res < 2**31
    except Exception as e:
      s = f"  Encountered an error while running report check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if report_check else constants.FAILURE_STR

  return results

#12
def CONFIG_EBS_OPP_MGR(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    mx_size_check = False
    try: # get params
      pull_opp_size = params[vm]["SQL_RESPONSES"]["PULL_OPP_SIZE"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: pull_opp_size\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(pull_opp_size["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # mx size check
      res = int(re.search("-mx(\d+)", pull_opp_size["result"][0]["DEVELOPER_PARAMETERS"]).group(1))
      logfile.write(f">>> LOGGING VARIABLE:\n  size: {res}\n")
      mx_size_check = res >= 2048
    except Exception as e:
      s = f"  Encountered an error while running mx size check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if mx_size_check else constants.FAILURE_STR

  return results

#21
def CONFIG_WORKFLOW_PURGE(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    purge_check = False
    orphan_check = False
    try: # get params
      workflow_purge_closed = params[vm]["SQL_RESPONSES"]["WORKFLOW_PURGE_CLOSED"]
      workflow_purge_orph_unref = params[vm]["SQL_RESPONSES"]["WORKFLOW_PURGE_ORPH_UNREF"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: workflow_purge_closed workflow_purge_orph_unref\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(workflow_purge_closed["log"])
      logfile.write(workflow_purge_orph_unref["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # purge check
      res = int(workflow_purge_closed["result"][0]["TOTAL_PURGEABLE"])
      logfile.write(f">>> LOGGING VARIABLE:\n  total_purgeable: {res}\n")
      purge_check = res < 10000
    except Exception as e:
      s = f"  Encountered an error while running purge check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try: # orphan check
      res = workflow_purge_orph_unref["result"]
      if len(res) == 0:
        orphan_check = True
      else:
        counts = []
        for item in res:
          try:
            count = item["COUNT"]
            logfile.write(f">>> LOGGING VARIABLE:\n  orphan count: {count}\n")
            count = int(count)
            counts += [count < 5000]
          except:
            pass
        orphan_check = all(counts)
    except Exception as e:
      s = f"  Encountered an error while running orphan check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if purge_check and orphan_check else constants.WARN_STR

  return results

#22
def CONFIG_WORKFLOW_STUCK(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    stuck_check = False
    try: # get params
      workflow_bkg_stuck = params[vm]["SQL_RESPONSES"]["WORKFLOW_BKG_STUCK"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: workflow_bkg_stuck\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(workflow_bkg_stuck["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # stuck check
      res = int(workflow_bkg_stuck["result"][0]["COUNT"])
      logfile.write(f">>> LOGGING VARIABLE:\n  count: {res}\n")
      stuck_check = res < 10000
    except Exception as e:
      s = f"  Encountered an error while running stuck check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if stuck_check else constants.WARN_STR

  return results

#23
def CONFIG_WORKFLOW_RETENTION(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    stuck_check = False
    try: # get params
      workflow_retention = params[vm]["SQL_RESPONSES"]["WORKFLOW_RETENTION"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: workflow_retention\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(workflow_retention["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # retention check
      res = int(workflow_retention["result"][0]["RETENTION"])
      logfile.write(f">>> LOGGING VARIABLE:\n  workflow_retention: {res}\n")
      stuck_check = res <= 365
    except Exception as e:
      s = f"  Encountered an error while running retention check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if stuck_check else constants.FAILURE_STR

  return results

#24
def CONFIG_PROFILE_LOGGING(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    logging_check = False
    try: # get params
      logging_bug = params[vm]["SQL_RESPONSES"]["LOGGING_BUG"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: logging_bug\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(logging_bug["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # logging check
      res = logging_bug["result"]
      res = {item["PROFILE_OPTION_NAME"]: item for item in res}
      aflog_level = res["AFLOG_LEVEL"]["PROFILE_OPTION_VALUE"]
      aflog_enabled = res["AFLOG_ENABLED"]["PROFILE_OPTION_VALUE"]
      logfile.write(f">>> LOGGING VARIABLES:\n  AFLOG_LEVEL: {aflog_level}\n  AFLOG_ENABLED: {aflog_enabled}\n")
      logging_check = aflog_level == "6" and aflog_enabled == "Y"
    except Exception as e:
      s = f"  Encountered an error while running logging check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if logging_check else constants.FAILURE_STR

  return results

#26
def CONFIG_DB_CONN(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    shoutput_check = False
    try: # get params
      show_cluster = params[vm]["SQL_RESPONSES"]["SHO_CLUSTER"]
      echo_two_task = params[vm]["SH_RESPONSES"]["ECHO_TWO_TASK"]
      tools_two_task = params[vm]["SH_RESPONSES"]["TOOLS_TWO_TASK"]
      cp_two_task = params[vm]["SH_RESPONSES"]["CP_TWO_TASK"]
      s_two_task = params[vm]["SH_RESPONSES"]["S_TWO_TASK"]
      jdbc_url = params[vm]["SH_RESPONSES"]["CHECK_JDBC_URL"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: show_cluster echo_two_task tools_two_task cp_two_task s_two_task jdbc_url\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(show_cluster["log"])
      logfile.write(echo_two_task["log"])
      logfile.write(tools_two_task["log"])
      logfile.write(cp_two_task["log"])
      logfile.write(s_two_task["log"])
      logfile.write(jdbc_url["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # show cluster check
      res = {item["NAME"]: item for item in show_cluster["result"]}["cluster_database"]["VALUE"]
      logfile.write(f">>> LOGGING VARIABLES:\n  show cluster: {res}\n")
      if res != "TRUE":
        results[vm] = constants.NA_STR
        continue
    except Exception as e:
      s = f"  Encountered an error while running show cluster check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try: # compare shell output check
      res = [echo_two_task["result"][0], tools_two_task["result"][0], cp_two_task["result"][0], s_two_task["result"][0]]
      logfile.write(f">>> LOGGING VARIABLES:\n  echo_two_task tools_two_task cp_two_task s_two_task: {res}\n  jdbc_url: {jdbc_url['result']}\n")
      shoutput_check = all([res[0] == obj for obj in res]) and len(jdbc_url["result"]) > 0
    except Exception as e:
      s = f"  Encountered an error while running compare shell output check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if shoutput_check else constants.FAILURE_STR

  return results

#28
def CONFIG_TDE(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    tde_check = False
    try: # get params
      tde_encryption = params[vm]["SQL_RESPONSES"]["TDE_ENCRYPTION"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: tde_encryption\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(tde_encryption["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # tde check
      res = int(tde_encryption["result"])
      logfile.write(f">>> LOGGING VARIABLES:\n  tde_encryption: {res}\n")
      tde_check = sum([1 if tbspc["ENCRYPTED"] == "NO" else 0 for tbspc in res]) > 0
    except Exception as e:
      s = f"  Encountered an error while running tde check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if tde_check else constants.FAILURE_STR

  return results

#38
def CONFIG_DB_PARAM_BKP_1(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    asm_diskgroup_size = -1
    db_recovery_size = -1
    size_check = False
    try: # get params
      asm_diskgroup = params[vm]["SQL_RESPONSES"]["GET_RECO"]
      db_recovery = params[vm]["SQL_RESPONSES"]["SHO_DB_RECOVERY_SIZE"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: asm_diskgroup db_recovery\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(asm_diskgroup["log"])
      logfile.write(db_recovery["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # size check
      asm_diskgroup_size = float(asm_diskgroup["result"][0]["TOTAL_GB"])
      db_recovery_size = float({item["NAME"]: item for item in db_recovery["result"]}["db_recovery_file_dest_size"]["VALUE"])
      logfile.write(f">>> LOGGING VARIABLES:\n  asm_diskgroup_size: {asm_diskgroup_size}\n  db_recovery_size: {db_recovery_size}\n")
      size_check = db_recovery_size >= 1.2 * asm_diskgroup_size
    except Exception as e:
      s = f"  Encountered an error while running size check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SKIP_STR if asm_diskgroup_size == -1 or db_recovery_size == -1 else\
      constants.SUCCESS_STR if size_check else constants.FAILURE_STR

  return results

#39
def CONFIG_DB_PARAM_BKP_2(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    file_check = False
    try: # get params
      db_recovery_file = params[vm]["SQL_RESPONSES"]["SHO_DB_RECOVERY"]
      db_log_file = params[vm]["SQL_RESPONSES"]["SHO_DB_LOG_DEST"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: db_recovery_file db_log_file\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(db_recovery_file["log"])
      logfile.write(db_log_file["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # file name check
      f1 = {item["NAME"]: item for item in db_recovery_file["result"]}["db_recovery_file_dest"]["VALUE"]
      f2 = {item["NAME"]: item for item in db_log_file["result"]}["db_create_online_log_dest_1"]["VALUE"]
      logfile.write(f">>> LOGGING VARIABLES:\n  db_recovery_file: {f1}\n  db_log_file: {f2}\n")
      file_check = f1 == "+RECO" and f2 == "+RECO"
    except Exception as e:
      s = f"  Encountered an error while running file name check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if file_check else constants.FAILURE_STR

  return results

#40
def CONFIG_DB_SQLNET(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    wallet_check = False
    try: # get params
      encryption_wallet = params[vm]["SH_RESPONSES"]["ENCRYPTION_WALLET"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: encryption_wallet\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(encryption_wallet["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # wallet check
      res = int(encryption_wallet["result"][0])
      logfile.write(f">>> LOGGING VARIABLES:\n  encryption wallet count: {res}\n")
      wallet_check = res >= 1
    except Exception as e:
      s = f"  Encountered an error while running wallet check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if wallet_check else constants.FAILURE_STR

  return results

#41
def EBS_CONC_REQ_1(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    fndwfpr_check = False
    try: # get params
      fndwfpr = params[vm]["SQL_RESPONSES"]["FNDWFPR"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: fndwfpr\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(fndwfpr["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # fndwfpr check
      res = int(fndwfpr["result"][0]["COUNT"])
      logfile.write(f">>> LOGGING VARIABLES:\n  count: {res}\n")
      fndwfpr_check = res >= 1
    except Exception as e:
      s = f"  Encountered an error while running fndwfpr check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if fndwfpr_check else constants.FAILURE_STR

  return results

#42
def EBS_CONC_REQ_2(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    fndwfbes_check = False
    try: # get params
      fndwfbes = params[vm]["SQL_RESPONSES"]["FNDWFBES_CONTROL_QUEUE_CLEANUP"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: fndwfbes\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(fndwfbes["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # fndwfbes check
      res = int(fndwfbes["result"][0]["COUNT"])
      logfile.write(f">>> LOGGING VARIABLES:\n  count: {res}\n")
      fndwfbes_check = res >= 1
    except Exception as e:
      s = f"  Encountered an error while running fndwfbes check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if fndwfbes_check else constants.FAILURE_STR

  return results

#43
def EBS_CONC_REQ_3(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    fndscprg_check = False
    try: # get params
      fndscprg = params[vm]["SQL_RESPONSES"]["FNDSCPRG"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: fndscprg\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(fndscprg["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # fndscprg check
      res = int(fndscprg["result"][0]["COUNT"])
      logfile.write(f">>> LOGGING VARIABLES:\n  count: {res}\n")
      fndscprg_check = res >= 1
    except Exception as e:
      s = f"  Encountered an error while running fndscprg check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if fndscprg_check else constants.FAILURE_STR

  return results

#44
def EBS_CONC_REQ_4(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    fndlgprg_check = False
    try: # get params
      fndlgprg = params[vm]["SQL_RESPONSES"]["FNDLGPRG"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: fndlgprg\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(fndlgprg["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # fndlgprg check
      res = int(fndlgprg["result"][0]["COUNT"])
      logfile.write(f">>> LOGGING VARIABLES:\n  count: {res}\n")
      fndlgprg_check = res >= 1
    except Exception as e:
      s = f"  Encountered an error while running fndlgprg check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if fndlgprg_check else constants.FAILURE_STR

  return results

#45
def EBS_CONC_REQ_5(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    mscatppurg_check = False
    try: # get params
      mscatppurg = params[vm]["SQL_RESPONSES"]["MSCATPPURG"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: mscatppurg\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(mscatppurg["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # mscatppurg check
      res = int(mscatppurg["result"][0]["COUNT"])
      logfile.write(f">>> LOGGING VARIABLES:\n  count: {res}\n")
      mscatppurg_check = res >= 1
    except Exception as e:
      s = f"  Encountered an error while running mscatppurg check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if mscatppurg_check else constants.FAILURE_STR

  return results

#46
def EBS_CONC_REQ_6(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    fnddltmp_check = False
    try: # get params
      fnddltmp = params[vm]["SQL_RESPONSES"]["FNDDLTMP"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: fnddltmp\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(fnddltmp["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # fnddltmp check
      res = int(fnddltmp["result"][0]["COUNT"])
      logfile.write(f">>> LOGGING VARIABLES:\n  count: {res}\n")
      fnddltmp_check = res >= 1
    except Exception as e:
      s = f"  Encountered an error while running fnddltmp check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if fnddltmp_check else constants.FAILURE_STR

  return results

#47
def EBS_CONC_REQ_7(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    fndgfmpr_check = False
    try: # get params
      fndgfmpr = params[vm]["SQL_RESPONSES"]["FNDGFMPR"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: fndgfmpr\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(fndgfmpr["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # fndgfmpr check
      res = int(fndgfmpr["result"][0]["COUNT"])
      logfile.write(f">>> LOGGING VARIABLES:\n  count: {res}\n")
      fndgfmpr_check = res >= 1
    except Exception as e:
      s = f"  Encountered an error while running fndgfmpr check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if fndgfmpr_check else constants.FAILURE_STR

  return results

#48
def EBS_CONC_REQ_8(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    fndwfbg_check = False
    try: # get params
      fndwfbg = params[vm]["SQL_RESPONSES"]["FNDWFBG"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: fndwfbg\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(fndwfbg["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # fndwfbg check
      res = int(fndwfbg["result"][0]["COUNT"])
      logfile.write(f">>> LOGGING VARIABLES:\n  count: {res}\n")
      fndwfbg_check = res >= 1
    except Exception as e:
      s = f"  Encountered an error while running fndwfbg check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if fndwfbg_check else constants.FAILURE_STR

  return results

#50
def EBS_CONC_REQ_10(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    rgoptm_check = False
    try: # get params
      rgoptm = params[vm]["SQL_RESPONSES"]["RGOPTM"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: rgoptm\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(rgoptm["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # rgoptm check
      res = int(rgoptm["result"][0]["COUNT"])
      logfile.write(f">>> LOGGING VARIABLES:\n  count: {res}\n")
      rgoptm_check = res >= 1
    except Exception as e:
      s = f"  Encountered an error while running rgoptm check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if rgoptm_check else constants.FAILURE_STR

  return results

#51
def EBS_CONC_REQ_11(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    gschstat_check = False
    try: # get params
      gschstat = params[vm]["SQL_RESPONSES"]["GSCHSTATCHECK"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: gschstat\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(gschstat["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # gschstat check
      res = int(gschstat["result"][0]["COUNT"])
      logfile.write(f">>> LOGGING VARIABLES:\n  count: {res}\n")
      gschstat_check = res >= 1
    except Exception as e:
      s = f"  Encountered an error while running gschstat check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if gschstat_check else constants.FAILURE_STR

  return results

#53
def EBS_CONC_REQ_13(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    progmst_check = False
    try: # get params
      progmst = params[vm]["SQL_RESPONSES"]["PROGMST"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: progmst\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(progmst["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # progmst check
      res = int(progmst["result"][0]["COUNT"])
      logfile.write(f">>> LOGGING VARIABLES:\n  count: {res}\n")
      progmst_check = res >= 1
    except Exception as e:
      s = f"  Encountered an error while running progmst check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if progmst_check else constants.FAILURE_STR

  return results

#56
def CONFIG_DB_PARA_PERF_1(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    fsys_check = False
    try: # get params
      fsys = params[vm]["SQL_RESPONSES"]["SHO_FSYS_OPTIONS"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: fsys\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(fsys["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # fsys check
      res = {item["NAME"]: item for item in fsys["result"]}["filesystemio_options"]["VALUE"]
      logfile.write(f">>> LOGGING VARIABLES:\n  filesystemio_options: {res}\n")
      fsys_check = res == "SETALL"
    except Exception as e:
      s = f"  Encountered an error while running fsys check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if fsys_check else constants.FAILURE_STR

  return results

#63
def ADOP_PATCHING_EBS_OLD_SESSION_CLEANUP(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    adopedition_check = False
    try: # get params
      adopedition = params[vm]["SQL_RESPONSES"]["ADOPEDITION"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: adopedition\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(adopedition["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # adopedition check
      res = int(adopedition["result"][0]["COUNT"])
      logfile.write(f">>> LOGGING VARIABLES:\n  count: {res}\n")
      adopedition_check = res < 1
    except Exception as e:
      s = f"  Encountered an error while running adopedition check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if adopedition_check else constants.FAILURE_STR

  return results

#64
def WEBLOGIC_EBS_STARTUP_ISSUES(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    dev_random_check = False
    secure_random_check = False
    java_sec_check = False
    try: # get params
      dev_random = params[vm]["SH_RESPONSES"]["LS_DEV_RANDOM"]
      secure_random = params[vm]["SH_RESPONSES"]["GREP_SECURE_RANDOM"]
      java_sec = params[vm]["SH_RESPONSES"]["GREP_JAVA_SECURITY"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: dev_random secure_random java_sec\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(dev_random["log"])
      logfile.write(secure_random["log"])
      logfile.write(java_sec["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # dev_random check
      res = dev_random["result"][0]
      dev_random_check = len(res) > 0
    except Exception as e:
      s = f"  Encountered an error while running dev_random check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try: # secure_random check
      res = secure_random["result"][0]
      secure_random_check = len(res) > 0
    except Exception as e:
      s = f"  Encountered an error while running secure_random check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try: # java_sec check
      res = java_sec["result"][0]
      java_sec_check = len(res) > 0
    except Exception as e:
      s = f"  Encountered an error while running java_sec check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if dev_random_check and secure_random_check and java_sec_check else constants.FAILURE_STR

  return results

#65
def EBS_MONITORING(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    oswatcher_check = False
    try: # get params
      oswatcher = params[vm]["SH_RESPONSES"]["OSWATCHER"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: oswatcher\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(oswatcher["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # oswatcher check
      res = oswatcher["result"]
      oswatcher_check = len(res) >= 1
    except Exception as e:
      s = f"  Encountered an error while running oswatcher check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if oswatcher_check else constants.FAILURE_STR

  return results

#66
def JRE_EBS_SECURITY(params):
  logfiles = None
  try: # get logfile objects
    logfiles = {vm: params[vm]["logfile"] for vm in params}
  except:
    print_debug("Unable to retrieve logfile objects. Skipping this check for all IPs.")
    return {vm: constants.ERROR for vm in params}

  results = {}
  for vm in params:
    logfile = logfiles[vm]
    jws_check = False
    profile_fnd_check = False
    profile_icx_check = False
    try: # get params
      s_forms_launch_method = params[vm]["SH_RESPONSES"]["S_FORMS_LAUNCH_METHOD"]
      profile_fnd_enable_jws = params[vm]["SQL_RESPONSES"]["PROFILE_FND_ENABLE_JWS"]
      profile_icx_forms_launcher = params[vm]["SQL_RESPONSES"]["PROFILE_ICX_FORMS_LAUNCHER"]
    except:
      s = f"  ERROR: Parameters could not be retrieved for node {vm}: s_forms_launch_method profile_fnd_enable_jws profile_icx_forms_launcher\n{params[vm]}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try:
      logfile.write(s_forms_launch_method["log"])
      logfile.write(profile_fnd_enable_jws["log"])
      logfile.write(profile_icx_forms_launcher["log"])
    except:
      print_debug(f"Warning: some logs could not be written for {vm}. Please check manual check log files at CODE/src/data/tmp/manualresults folder, as well as the JSON files created by scripts_sh.sh and scripts_sql.sql.")

    try: # jws check
      res = xmltodict.parse(s_forms_launch_method["result"][-1])["config_option"]["#text"]
      logfile.write(f">>> LOGGING VARIABLE:\n  jws option: {res}\n")
      jws_check = res == "JWS"
    except Exception as e:
      s = f"  Encountered an error while running jws check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try: # profile fnd check
      res = profile_fnd_enable_jws["result"][0]["VALUE"]
      logfile.write(f">>> LOGGING VARIABLE:\n  fnd_enable_jws: {res}\n")
      profile_fnd_check = res in ("Yes", "Y")
    except Exception as e:
      s = f"  Encountered an error while running profile fnd check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    try: # profile icx check
      res = [item["VALUE"] for item in profile_icx_forms_launcher["result"]]
      logfile.write(f">>> LOGGING VARIABLE:\n  icx_forms_launcher: {str(res)}\n")
      profile_icx_check = all([url.split("?")[-1].find("config=jws") != -1 for url in res])
    except Exception as e:
      s = f"  Encountered an error while running profile icx check for node {vm}:\n{e}\n"
      print_debug(s)
      logfile.write(s)
      results[vm] = constants.ERROR
      continue

    results[vm] = constants.SUCCESS_STR if jws_check and profile_fnd_check and profile_icx_check else constants.FAILURE_STR

  return results
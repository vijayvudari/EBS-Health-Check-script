#########################################################################################
###################################### CONSTANTS ########################################
#########################################################################################

# Success and Failure strings for easy edit
SUCCESS_STR = "PASS"
FAILURE_STR = "FAIL"
WARN_STR = "WARNING"
NA_STR = "NOT APPLICABLE"
SKIP_STR = NA_STR
ERROR = "ERROR"

# Logfile default string
LOGFILE_DEFAULT = "No Logs Generated.\n"
LOGFILE_ERROR = "Encountered an error while running this check:\n"
LOGFILE_SKIP = "Skipping this IP address for this check.\n"
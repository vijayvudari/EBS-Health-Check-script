#########################################################################################
################################### HELPER FUNCTIONS ####################################
#########################################################################################

import json
import time

# @params
# res - dictionary of test results
# filename - target name for JSON output
# @return
# None
def write_output(res, filename):
  with open(filename, 'w') as outfile:
    json.dump(res, outfile)


# @params
# none
# @return
# current time, e.g. 2000-10-31T13-00-59Z+07:00
def get_time():
  return time.strftime("%Y-%m-%dT%H-%M-%SZ%z")


def print_debug(s, log=None):
  #print(s)
  if log is not None and type(log) is str:
    return f"{log}\n{str(s)}"
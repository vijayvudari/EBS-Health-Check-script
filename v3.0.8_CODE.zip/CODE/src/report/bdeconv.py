import json
from bs4 import BeautifulSoup
import os.path
import sys

filepath = os.path.dirname(os.path.abspath(__file__))

def fileCheck(fn):
    try:
        open(fn, 'r')
        return 1
    except IOError:
        print('Error: ' + fn +' not found.')
        return 0

#print('Enter BDE check file path(or leave blank for sample report): ')
#file1 = input()
file1=sys.argv[1]
fileCheck(file1)

data = {}
output = filepath+'/../data/tmp/bde.json'
with open(file1) as inf:
    txt = inf.read()
    soup = BeautifulSoup(txt, 'html.parser')

#print(soup.find_all('table')[1])

system = soup.find_all('table')[0]
parameters = soup.find_all('table')[1]
release = soup.find_all('table')[2]
removals = soup.find_all('table')[3]
custom = soup.find_all('table')[4]

data['system'] = []
#for tr in system.find_all('tr')[1:]:
#    print('no')
    

data['recommendations'] = []
for tr in parameters.find_all('tr')[1:]:
    para = tr.find_all('td')[0].text
    curr = tr.find_all('td')[1].text
    required = tr.find_all('td')[2].text
    cbo = tr.find_all('td')[3].text
    mp = tr.find_all('td')[4].text 
    sz = tr.find_all('td')[5].text
    data['recommendations'].append({
        'parameter': para,
        'current value': curr,
        'required value': required,
        'cbo': cbo,
        'mp': mp,
        'sz': sz
    })

data['release'] = []
for tr in release.find_all('tr')[1:]:
    para = tr.find_all('td')[0].text
    curr = tr.find_all('td')[1].text
    required = tr.find_all('td')[2].text
    cbo = tr.find_all('td')[3].text
    mp = tr.find_all('td')[4].text 
    sz = tr.find_all('td')[5].text
    data['release'].append({
        'parameter': para,
        'current value': curr,
        'required value': required,
        'cbo': cbo,
        'mp': mp,
        'sz': sz
    })

data['removals'] = []
for tr in removals.find_all('tr')[1:]:
    removal = tr.find_all('td')[0].text
    curr = tr.find_all('td')[1].text
    data['removals'].append({ 
        'parameter': removal,
        'current value': curr
     })

data['custom'] = []
for tr in custom.find_all('tr')[1:]:
    para = tr.find_all('td')[0].text
    curr = tr.find_all('td')[1].text
    data['custom'].append({
        'parameter': para,
        'current value': curr
    })

with open(output, 'w') as outfile:
    json.dump(data, outfile, indent=4)




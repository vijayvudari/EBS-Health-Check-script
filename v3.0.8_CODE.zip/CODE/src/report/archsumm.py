from bs4 import BeautifulSoup
import os.path
from config import config as cfg
import json

filepath = os.path.dirname(os.path.abspath(__file__))

def fileCheck(fn):
    try:
        open(fn, "r")
        return 1
    except IOError:
        print("Error: " + fn +" not found.")
        return 0

def wrap_details(s):
    wrapper = report.new_tag('pre', attrs = {'style': 'text-align: left; white-space: pre-wrap'})
    details = report.new_tag('code')
    details.append(s)
    wrapper.append(details)
    return wrapper

file1 = filepath+"/../../healthcheck-report.html"
fileCheck(file1)
with open(file1) as f:
    txt = f.read()
    report = BeautifulSoup(txt, "html.parser")

vm_list = cfg["VM List"]
sql_file = cfg["DB Info"]["JSON File"]
with open(sql_file) as f:
    sql_data = json.load(f)
ebs_version = sql_data["EBS_VERSION"]["result"][0]["EBS_VERSION"]
db_version = sql_data["DB_VERSION"]["result"][0]["DB_VERSION"]
node_details = sql_data["NODE_DETAIL"]["result"]
#print(node_details)

DB_VMs = [item["VM Name"] for item in vm_list if item["VM Type"] in ["D", "B"]]
APP_VMs = [item["VM Name"] for item in vm_list if item["VM Type"] in ["A", "B"]]

arch_summ = report.find("div", {"id": "system"})
td_ebs_version = arch_summ.find("td", {"class": "EBS-Version"})
td_ebs_version.append(str(ebs_version))
td_db_version = arch_summ.find("td", {"class": "Database-Version"})
td_db_version.append(str(db_version))
detail_table = arch_summ.find("table", {"id": "system-details"})
node_detail_table = arch_summ.find("table", {"id": "node-details"})

sys_details_raw = []
for server in vm_list:
    sh_file = server["JSON File"]
    with open(sh_file) as f:
        sh_data = json.load(f, strict=False)
        sys_details_raw += [{
            "NAME": server["VM Name"],
            "CPU": sh_data["CPU"],
            "MEM": sh_data["MEM"],
            "DISK": sh_data["DISK"],
            "CPU_MODEL": sh_data["CPU_MODEL"]
        }]
#print(sys_details_raw)

for sys_detail in sys_details_raw:
    curr_sys_detail = report.new_tag("tr")
    sys_name = report.new_tag("td")
    sys_name.append(wrap_details(sys_detail["NAME"]))
    sys_cpu = report.new_tag("td")
    sys_cpu.append(wrap_details(sys_detail["CPU"]["result"]))
    sys_mem = report.new_tag("td")
    sys_mem.append(wrap_details(sys_detail["MEM"]["result"]))
    sys_cpu_model = report.new_tag("td")
    sys_cpu_model.append(wrap_details(sys_detail["CPU_MODEL"]["result"]))
    sys_disk = report.new_tag("td")
    sys_disk.append(wrap_details(sys_detail["DISK"]["result"]))
    curr_sys_detail.append(sys_name)
    curr_sys_detail.append(sys_cpu)
    curr_sys_detail.append(sys_cpu_model)
    curr_sys_detail.append(sys_mem)
    curr_sys_detail.append(sys_disk)
    detail_table.append(curr_sys_detail)

for node_detail in node_details:
    curr_node_detail = report.new_tag("tr")
    node_name = report.new_tag("td")
    node_name.append(wrap_details(node_detail["NODE_NAME"]))
    support_cp = report.new_tag("td")
    support_cp.append(wrap_details(node_detail["SUPPORT_CP"]))
    support_forms = report.new_tag("td")
    support_forms.append(wrap_details(node_detail["SUPPORT_FORMS"]))
    support_web = report.new_tag("td")
    support_web.append(wrap_details(node_detail["SUPPORT_WEB"]))
    support_admin = report.new_tag("td")
    support_admin.append(wrap_details(node_detail["SUPPORT_ADMIN"]))
    support_db = report.new_tag("td")
    support_db.append(wrap_details(node_detail["SUPPORT_DB"]))
    curr_node_detail.append(node_name)
    curr_node_detail.append(support_cp)
    curr_node_detail.append(support_forms)
    curr_node_detail.append(support_web)
    curr_node_detail.append(support_admin)
    curr_node_detail.append(support_db)
    node_detail_table.append(curr_node_detail)

f = open(file1, "w")
f.write(report.prettify())
f.close()
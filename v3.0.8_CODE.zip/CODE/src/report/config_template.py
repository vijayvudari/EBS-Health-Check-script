config = {
    "VM List": [
        {
            "VM Name": "EBSAPP01",
            "VM Type": "A",
            "JSON File": "/location/of/shoutput_EBSAPP.json"
        },
        {
            "VM Name": "EBSDB01",
            "VM Type": "D",
            "JSON File": "/location/of/shoutput_EBSDB.json"
        }
    ],
    "DB Info": {
        "JSON File": "/location/of/sql_data.json"
    },
    "EBS Info": {
        "EBS Version": "12.2"
    }
}
report = {
    "bdecheck":        "yes",
    "bdereport":       "/location/of/bde_chk_cbo_report.html",
    "oracheck results": None,
    "oracheck reco":    None,
    "exacheck results":"/location/of/upload/instancename_exachk_results.json",
    "exacheck reco":   "/location/of/upload/exachk_recommendations.json",
    "ora or exa":      "exa"
}
import os
import time
from config import report

pycmd = "python3" # change this if the script results in an error

print("\ncleaning tmp directory")
os.system("rm -rf ../data/tmp/*")
os.system("mkdir -p ../data/tmp")

print("\ngenerating healthcheck file")
healthcheck_file = "../../healthcheck-report.html"
if os.path.exists(healthcheck_file) and os.path.isfile(healthcheck_file):
	os.system(f"mv {healthcheck_file} ../../healthcheck-report_{time.time()}.html")
	print("\texisting file moved")
os.system("cp healthcheck-template.html ../../healthcheck-report.html")

print("\nincorporating bdechecks into report")
if report["bdecheck"] == "Y":
	os.system(f"{pycmd} bdeconv.py {report['bdereport']}")
	os.system(f"{pycmd} bdereport.py")
else:
	print("\tno BDE check was configured in the config file. Skipping")

print("\nincorporating ora/exa checks into report")
if report["ora or exa"]=="ora":
	os.system(f"{pycmd} oraconv.py {report['oracheck results']} {report['oracheck reco']}")
else:
	os.system(f"{pycmd} exaconv.py {report['exacheck results']} {report['exacheck reco']}")	
os.system(f"{pycmd} orareport.py")

print("\nincorporating manualchecks into report")
os.system(f"{pycmd} manualconv.py")
os.system(f"{pycmd} manualreport.py")

print("\ngenerating ebs score")
os.system(f"{pycmd} ebsscore.py")

print("\ngenerating architecture summary")
os.system(f"{pycmd} archsumm.py")

print("\ngenerating executive summary")
os.system(f"{pycmd} execsumm.py")

print("\nDone!")
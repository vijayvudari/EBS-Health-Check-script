import json
import getpass
from manualcheck.helperfuncs import *

######## Globals ########
vm_list = [] # list of VM hosts
""" model for vm_list
[{
    "VM Name": vm_node_name,
    "VM Type": vm_type,
    "JSON File": vm_query_json
]}
"""

db_info = {} # object of DB info
""" model for db_info
{
    "DB Name": "",
    "DB Version": "",
    "JSON File": ""
}
"""

ebs_info = {} # object of ebs version info
""" model for ebs_info
{
    "EBS Name": "",
    "EBS Version": "12.0.1.3"
}
"""

oci = { "Path": "", "Profile": "" } # used for OCI checks

report = {} # used for report parameters
""" model for report (example)
{
    "bdecheck":        "yes",
    "bdereport":       "/location/of/bde_chk_cbo_report.html",
    "oracheck results": None,
    "oracheck reco":    None,
    "exacheck results":"/location/of/upload/instancename_exachk_results.json",
    "exacheck reco":   "/location/of/upload/exachk_recommendations.json",
    "ora or exa":      "exa"
}
"""

######## Helpers #########

"""
Validation functions

These functions are used to validate input and are passed into the "validation_function" parameter for the "input_common" function (the default value of this parameter is a lambda function which takes in one input and always returns True). Because these functions only validate one input, they must always have exactly one input. These functions will return True if the input was valid and False otherwise.
These functions will be responsible for printing clarification statements to the terminal if the input is not valid.
"""
""" def key_checks(key):
    if len(key) == 0:
        print("Empty path.")
        return False
    if key in ssh_key_list:
        print("Duplicate keys.")
        return False
    return True """

""" def oci_checks(oci_path):
    if len(oci_path) == 0:
        print("Empty path.")
        return False
    return True """

""" def is_ip(ip):
    parts = ip.split(".")
    try:
        if len(parts) == 4 and all(0 <= int(part) <= 255 for part in parts):
            return True
        else:
            print("Invalid IP address (e.g. 192.0.0.1)")
    except ValueError: 
        print("Invalid IP address (e.g. 192.0.0.1)")
    return False """

def check_vm_type(node_type):
    if node_type.upper() in "A,D,B".split(","):
        return True
    else:
        print("Invalid option, type A for application, D for database, or B for both.")
        return False

"""
Input functions

These are input functions to reduce the code clutter in the main method. Each implementation (except for input_password) prompts for input and loops if the input is not valid. Their usages are as follows:
- input_common: This input function is the most flexible one, as it loops continuously until the input passes the validation_function. By default, this validation_function always returns true. For more information on validation functions, see the above section on "Validation Functions".
- input_integer: This input function checks if the input is in the set of positive or nonnegative integers, depending on if the "pos_only" flag is set. If "pos_only" is False, then 0 is included (nonnegative = False, positive only = True). Returns parsed number cast as an integer.
- input_yn: This input function checks if the input is yes or no, and is consequently only used for questions that require yes/no answers. The function uses a small set of "accepts" and "rejects" to determine if the response is yes/no. Returns "Y" on yes and "N" on no. Future developers may opt to add more options for yes/no [TODO].
- input_nonempty: This input function checks if the input is empty and reprompts on empty input. Invocations can optionally specify a second parameter called reprompt, which displays the reprompt message if the input is empty.
- input_password: This input function uses the getpass library to input a password while hiding the user input from the terminal. WARNING TO USERS: this function only allows you to input your password once, so make sure you type it correctly or copy-paste it from your password storage location.
"""
def input_common(query, validation_function = lambda x:True):
    while True:
        result = input(query)
        if validation_function(result):
            return result

def input_integer(query, pos_only = False):
    while True:
        result = input(query)
        if str.isnumeric(result):
            if int(result) >= (1 if pos_only else 0):
                return int(result)
            else:
                print(f"Invalid number, input a {'positive' if pos_only else 'nonnegative'} integer.")
        else:
            print(f"Invalid input, input a {'positive' if pos_only else 'nonnegative'} integer.")

def input_yn(query):
    accept = ["Y", "YES"]
    reject = ["N", "NO"]
    while True:
        result = input(query)
        if result.upper() in accept:
            return "Y"
        elif result.upper() in reject:
            return "N"
        else:
            print(f"Please respond with yes (e.g. {accept[:3]}) or no (e.g. {reject[:3]})")

def input_nonempty(query, reprompt="Please enter a nonempty input."):
    while True: 
        result = input(query)
        if len(result) > 0:
            return result
        else:
            print(reprompt)

def input_password(query):
    password = getpass.getpass(query)
    if len(password) == 0:
        password = None
    return password

"""
Auxiliary functions

Extra functions with no particular category
"""
# Used to select a single element from the given list, for instance selecting one SSH key from a list of multiple. Uses "lst_key" to determine which element of the dict to access and return. Only processes lists with the model [{lst_key: "", ...}].
def select_from_multiple(query, lst, lst_key):
    while True:
        print(query)
        for i in range(len(lst)):
            print(f"({i+1}): {lst[i][lst_key]}")
        obj = input()
        if str.isnumeric(obj):
            obj = int(obj) - 1
            if obj < 0 or obj >= len(lst):
                print("Invalid choice.")
            else:
                return lst[obj][lst_key]
        else:
            print("Invalid choice.")




######## Prompting #########
def main():


    print("\n------CONFIGURING VM NODES------\n")
    num_VMs = input_integer("Enter the number of vm hosts to configure: ", pos_only = True)
    for i in range(num_VMs):
        print(f"----\n(VM host #{i+1})")
        vm_node_name = input_nonempty(f"Input the name of your VM node (e.g. ebsapp01): ")
        vm_type = input_common(f"Please enter the VM type (A for application, D for database, B for both) of the VM host ({vm_node_name}): ", validation_function = check_vm_type)
        vm_query_json = input_nonempty("Please enter the full path of the terminal command output JSON file (e.g. /home/opc/shoutput_ebsapp01.json): ")

        vm_list.append({
            "VM Name": vm_node_name,
            "VM Type": vm_type.upper(),
            "JSON File": vm_query_json
        })

    print("\n------VM NODE SUMMARY------\n")
    print("HOSTS SAVED:\n")
    for i in range(len(vm_list)):
        print(f"{i+1}: {vm_list[i]['VM Name']}")


    print("\n------CONFIGURING DATABASE------\n")
    db_query_json = input_nonempty(f"Please enter the full path of the SQL query output JSON file (e.g. /home/opc/sql_data.json): ")

    db_info["JSON File"] = db_query_json


    print("\n------CONFIGURING EBS------\n")
    ebs_version = input_nonempty("Please enter the EBS version (e.g. 12.1.3): ")

    ebs_info["EBS Version"] = ebs_version


    print("\n------CONFIGURING REPORT PARAMETERS------\n")
    bde_check = input_yn(f"Do you have a BDE report: ")
    bde_report = None
    if bde_check == "Y":
        bde_report = input_nonempty(f"Please enter the full path of your completed BDE report HTML file (e.g. /home/opc/bde_chk_cbo_report.html): ")
    ora_or_exa = select_from_multiple("Choose whether you used oracheck or exacheck: ", [{"i": "ora"}, {"i": "exa"}], "i")
    oracheck_results, oracheck_reco, exacheck_results, exacheck_reco = None, None, None, None
    if ora_or_exa == "ora":
        oracheck_results = input_nonempty(f"Please enter the full path of your completed oracheck report JSON file (e.g. /home/opc/[ORACHK UNZIPPED FOLDER]/upload/[DBNAME]_orachk_results.json): ")
        oracheck_reco = input_nonempty(f"Please enter the full path of your completed oracheck recommendations JSON file (e.g. /home/opc/[ORACHK UNZIPPED FOLDER]/upload/orachk_recommendations.json): ")
    if ora_or_exa == "exa":
        exacheck_results = input_nonempty(f"Please enter the full path of your completed exacheck report JSON file (e.g. /home/opc/[EXACHK UNZIPPED FOLDER]/upload/[DBNAME]_exachk_results.json): ")
        exacheck_reco = input_nonempty(f"Please enter the full path of your completed exacheck recommendations JSON file (e.g. /home/opc/[EXACHK UNZIPPED FOLDER]/upload/exachk_recommendations.json): ")

    report["bdecheck"] = bde_check
    report["bdereport"] = bde_report
    report["oracheck results"] = oracheck_results
    report["oracheck reco"] = oracheck_reco
    report["exacheck results"] = exacheck_results
    report["exacheck reco"] = exacheck_reco
    report["ora or exa"] = ora_or_exa

    print("\n------REPORT PARAM SUMMARY------\n")
    print(report)


    config = {
        "VM List": vm_list,
        "DB Info": db_info,
        "EBS Info": ebs_info
    }


    print("\n------WRITING EBS CONFIGURATION TO 'config.py'------\n")

    with open("config.py", "w") as f:
        f.write("config = " + json.dumps(config, indent=4).replace("null", "None").replace('""', 'None'))
        f.write("\n")
        f.write("report = " + json.dumps(report, indent=4).replace("null", "None").replace('""', 'None'))

    print("\n------DONE------")

main()

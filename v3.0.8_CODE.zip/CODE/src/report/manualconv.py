import json
import os

import sys
sys.path.append("manualcheck")
from constants import *
from checkfuncs import *
from checkfunc_list import checks
from helperfuncs import *

from config import config

log = ""

# pull information from config file
try: # VM information
    nodes = config["VM List"]
except Exception as e:
    log = print_debug(f"Ran into an error while importing VM info. Please check the config file. Error:\n{e}", log)
    nodes = None
try: # Database information
    DB_info = config["DB Info"]
except Exception as e:
    log = print_debug(f"Ran into an error while importing DB info. Please check the config file. Error:\n{e}", log)
    DB_info = None
try: # EBS information
    EBS_info = config["EBS Info"]
except Exception as e:
    log = print_debug(f"Ran into an error while importing EBS info. Please check the config file. Error:\n{e}", log)
    EBS_info = None

# pulling data from data files
SQL_responses = {}
try: # attempt to get the sql responses
    with open(DB_info["JSON File"]) as f:
        SQL_responses = json.load(f, strict=False)
except:
    log = print_debug("Unable to retrieve SQL responses. Stopping program.", log)
    raise Exception
SH_responses = {}
try: # attempt to get the sh responses
    for node in nodes:
        try:
            vm_name = node["VM Name"]
            with open(node["JSON File"]) as f:
                SH_responses[vm_name] = json.load(f, strict=False)
        except Exception as e:
            log = print_debug(e, log)
            log = print_debug(f"Unable to read {node['JSON File'] if 'JSON File' in node else 'JSON file'}. Skipping...", log)
except:
    log = print_debug("Uncaught exception while attempting to retrieve all SH responses. Stopping program.", log)
    raise Exception
app_vms = [node["VM Name"] for node in nodes if node["VM Type"].upper() in ["A", "B"]]
db_vms = [node["VM Name"] for node in nodes if node["VM Type"].upper() in ["D", "B"]]
both_vms = [node["VM Name"] for node in nodes]

# set up the output directory on where to write results to
filepath = os.path.dirname(os.path.abspath(__file__))
outputDir = filepath + "/../data/tmp/manualresults"
try:
    os.makedirs(outputDir, exist_ok=True)
    for node in nodes:
        vm_name = node["VM Name"]
        os.makedirs(os.path.join(outputDir, "LOGFILES", vm_name))
except:
    log = print_debug("Could not instantiate directories. Please check your user permissions"\
    " for creating files and directories in this machine, then re-run this script.\n"\
    f"Directory:\n{outputDir}", log)
    raise Exception("Could not instantiate directories.")

# iterating all checks and performing a check for all IPs
output_results = {}
log = print_debug("=====BEGIN MANUAL CHECK CONVERSION=====", log)
for check in checks:
    tmp_check_result = {}
    check_name = check["name"]
    check_func = check["function"]
    check_type = check["type"]
    check_params = check["params"]
    log_dict = {}
    log = print_debug(f">>> Running {check_name} check", log)

    vms = {}
    if check_type == "application":
        vms = app_vms
    elif check_type == "database":
        vms = db_vms
    elif check_type == "both":
        vms = both_vms
    else:
        log = print_debug(f"Check type {check_type} not recognized. Skipping this check...", log)
        continue
    if check_type != "lboci":
        params = {}
        for vm in vms: # generate parameters
            skip_check = False
            try:
                params[vm] = {
                    "SH_RESPONSES": {},
                    "SQL_RESPONSES": {},
                    "EBS_VERSION": EBS_info["EBS Version"]
                }
                if "SH" in check_params:
                    for sh_id in check_params["SH"]:
                        if sh_id in SH_responses[vm]:
                            params[vm]["SH_RESPONSES"][sh_id] = SH_responses[vm][sh_id]
                            params[vm]["SH_RESPONSES"][sh_id]["result"] = params[vm]["SH_RESPONSES"][sh_id]["result"].split("\n")
                            if params[vm]["SH_RESPONSES"][sh_id]["result"][-1] == "" and len(params[vm]["SH_RESPONSES"][sh_id]["result"]) > 1:
                                params[vm]["SH_RESPONSES"][sh_id]["result"] = params[vm]["SH_RESPONSES"][sh_id]["result"][:-1]
                        else:
                            log = print_debug(f"  Warning: data missing for parameter {sh_id}. Skipping this parameter", log)
                if "SQL" in check_params:
                    for sql_id in check_params["SQL"]:
                        if sql_id in SQL_responses:
                            params[vm]["SQL_RESPONSES"][sql_id] = SQL_responses[sql_id]
                        else:
                            log = print_debug(f"  Warning: data missing for parameter {sql_id}. Skipping this parameter", log)
            except Exception as e:
                log = print_debug(f"  Error: could not instantiate parameter set for {vm}. Skipping this check. Error:\n{e}", log)
                temp_check_result = {vm: constants.ERROR for vm in vms}
                for vm in vms:
                    with open(os.path.join(os.path.join(outputDir, "LOGFILES", vm), check_name), "w") as f:
                        f.write(constants.LOGFILE_ERROR + str(e))
                skip_check = True
        if skip_check:
            continue
        for vm in vms: # create logfiles
            filepath = os.path.join(os.path.join(outputDir, "LOGFILES", vm), check_name)
            params[vm]["logfile"] = open(filepath, "w")
        results = None
        try: # run check, returns {ip: "result string as defined in constants.py"}
            results = check_func(params)
        except Exception as e:
            log = print_debug(f"  Check ran into uncaught exception for node {vm} with the following message: {str(e)}", log)
            res = constants.ERROR + str(e)
        for vm in params: # close logfiles to write buffers
            params[vm]["logfile"].close()
        tmp_check_result = results

    # validate results of checks and write logfile
    if tmp_check_result:
        output_results[check_name] = tmp_check_result
    else:
        log = print_debug("Null results object returned. No results to write for this check.", log)

log = print_debug("======END MANUAL CHECK CONVERSION======", log)

outputTarget = os.path.join(outputDir, 'results.json')
write_output(output_results, outputTarget)
with open("manualconv_logs.txt", "w") as f:
    f.write(log)
import json
import os.path
import sys

filepath = os.path.dirname(os.path.abspath(__file__)) 
def fileCheck(fn):
    try:
        open(fn, 'r')
        return 1
    except IOError:
        print('Error: ' + fn +' not found.')
        return 0

# print('Enter Oracheck results file path(or leave blank for sample report): ')
# file1 = input()
file1=sys.argv[1]

# print('Enter Oracheck recommendations file path(or leave blank for sample report): ')
# file2 = input()
file2=sys.argv[2]
fileCheck(file1)
fileCheck(file2)

with open(file1) as json_file:
    results = json.load(json_file)

with open(file2) as json_file:
    recommendations = json.load(json_file)

output = filepath+'/../data/tmp/ora.json'
#results = results['results']
#recommendations = recommendations['results']
data = {}
count = 0

def cleanDetails(detail, name):
    if name == '':
        return detail
    subsetIdx = [i for i in range(len(detail)) if detail.startswith('DATA FROM', i)]
    subset = ''
    if len(subsetIdx) < 2:
        subset = detail
    else:
        for i in range(1,len(subsetIdx)):
            a = subsetIdx[i-1]
            b = subsetIdx[i]
            if name in detail[a:b]:
                subset = detail[a:b]
                break
    return subset
    
##Formatting JSON oracheck data into required data structures
for result in results:
    oraID = result['orachkID']
    parameter = '' if 'NodeName' not in result else result['NodeName']
    if parameter == '':
        parameter = '' if 'DBName' not in result else result['DBName']
    status = '' if 'orachkStatus' not in result else result['orachkStatus']
    statusCode = '' if 'orachkStatusCode' not in result else result['orachkStatusCode']
    instance = '' if 'InstanceName' not in result else result['InstanceName']
    target = '' if 'orachkTargetType' not in result else result['orachkTargetType']
    details = '' if 'orachkMsgDetail' not in result else result['orachkMsgDetail']
    instName = '' if len(instance) == 0 else instance[:len(instance)-1] 
    #details = cleanDetails(details, instName)
    newParam = {
        'parameter': parameter,
        'target': target,
        'status': status,
        'statusCode': statusCode,
        'instance': instance,
        'details': details
    }
    if oraID not in data:
        message = '' if 'orachkmessage' not in result else result['orachkmessage']
        oraType = '' if 'orachkType' not in result else result['orachkType']
        alert = '' if 'orachkAlertType' not in result else result['orachkAlertType']
        name = '' if 'orachkName' not in result else result['orachkName']
        node = '' if 'NodeName' not in result else result['NodeName']
        if node == '':
            node = '' if 'DBName' not in result else result['DBName']
        recommendation = ''
        for item in recommendations:
            if oraID == item['orachkID']:
                recommendation = item['Recommendation']
        newCol = {
            'name': name,
            'type': oraType,
            'message': message,
            'recommendation': recommendation,
            'node': node,
            'alert': alert,
            'parameters': []
        }
        data[oraID] = newCol
    data[oraID]['parameters'].append(newParam)

f = open(output, 'w')
json.dump(data, f, indent=4)
f.close()

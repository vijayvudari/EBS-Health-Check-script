#!/bin/bash

echo -e "Setting variables..."

CPU='cat /proc/cpuinfo | grep -i processor | wc -l'
MEM='cat /proc/meminfo | grep -i MemTotal'
DISK='df -h'
CPU_MODEL='cat /proc/cpuinfo | grep -i "model name" | uniq'

S_BATCH_STATUS='grep -i s_batch_status $CONTEXT_FILE'
FIND_LIBR='ps -ef | grep -i [f]ndlibr | wc -l'
CHECK_APPLLDM='grep -i APPLLDM $CONTEXT_FILE'
CRONTAB_BKUP_START='crontab -l | grep bkup_start | grep -i EBSDB | wc -l'
S_PIDS_DIR='fs=`grep -i s_pids_dir $CONTEXT_FILE | grep -o ">/.*<" | sed -En "s/>\/(\w+)\/.*/\1/p"`; echo $fs'
CHECK_PIDS_DIR='mount | grep -i "/$fs" | grep -i "type nfs" | wc -l'
S_OACORE_NPROCS='grep -i s_oacore_nprocs $CONTEXT_FILE'
CHECK_OACORE='grep -i s_oacore_managed_servers $CONTEXT_FILE'
CHECK_RESPONSE_XMS='grep -i Xms $EBS_DOMAIN_HOME/config/config.xml | grep -i oacore_server'
CHECK_SIZE_REPORTS='ls -l $APPLCSF/$APPLLOG/reports.log'
ECHO_TWO_TASK='echo $TWO_TASK'
TOOLS_TWO_TASK='grep s_tools_twotask $CONTEXT_FILE'
CP_TWO_TASK='grep s_cp_twotask $CONTEXT_FILE'
S_TWO_TASK='grep s_weboh_twotask $CONTEXT_FILE'
CHECK_JDBC_URL='grep jdbc_url $CONTEXT_FILE | grep scan'
ENCRYPTION_WALLET='grep encryption_wallet -i $ORACLE_HOME/network/admin/sqlnet.ora | wc -l'
LS_DEV_RANDOM='ls -lR /dev/*random* | grep ^l'
GREP_SECURE_RANDOM='grep -i securerandom.source $FMW_HOME/webtier/jdk/jre/lib/security/java.security | grep -v "#"'
GREP_JAVA_SECURITY='grep -i "java.security.egd" $EBS_DOMAIN_HOME/bin/startWebLogic.sh'
OSWATCHER='ps -ef | grep OSWatcher | grep -v grep'
S_FORMS_LAUNCH_METHOD='grep -i s_forms_launch_method $CONTEXT_FILE'

FILE_NAME="shoutput.json"

echo -e "Writing header to JSON file..."

printf "{\n" > $FILE_NAME

echo -e "Defining function..."

outputJSON() {
    name="$1"
    cmd=$(echo "$2" | sed 's/\\/\\\\/g' | sed 's/\"/\\"/g')
    ret=$(eval "$2" | sed 's/\"/\\"/g' | sed -z 's/\n/\\n/g')
    printf "\t\"$name\": {\n" >> $FILE_NAME
    printf "\t\t\"command\": \"%s\",\n" "$cmd" >> $FILE_NAME
    printf "\t\t\"result\": \"%s\",\n" "$ret" >> $FILE_NAME
    printf '\t\t"log": ">>> TERMINAL QUERY:\\n'"%s"'\\n>>> TERMINAL RESULT:\\n'"%s"'\\n"\n' "$cmd" "$ret" >> $FILE_NAME
}

if [ -z "$CONTEXT_FILE" ]; then CONTEXT_FILE="."; fi

# environment details

echo -e "CPU"

CPU=$CPU
outputJSON CPU "$CPU"
printf  "\t},\n" >> $FILE_NAME

echo -e "MEM"

MEM=$MEM
outputJSON MEM "$MEM"
printf  "\t},\n" >> $FILE_NAME

echo -e "DISK"

DISK=$DISK
outputJSON DISK "$DISK"
printf  "\t},\n" >> $FILE_NAME

echo -e "CPU_MODEL"

CPU_MODEL=$CPU_MODEL
outputJSON CPU_MODEL "$CPU_MODEL"
printf  "\t},\n" >> $FILE_NAME

# check parameters

echo -e "S_BATCH_STATUS"

S_BATCH_STATUS=$S_BATCH_STATUS
outputJSON S_BATCH_STATUS "$S_BATCH_STATUS"
printf  "\t},\n" >> $FILE_NAME

echo -e "FIND_LIBR"

FIND_LIBR=$FIND_LIBR
outputJSON FIND_LIBR "$FIND_LIBR"
printf  "\t},\n" >> $FILE_NAME

echo -e "CHECK_APPLLDM"

CHECK_APPLLDM=$CHECK_APPLLDM
outputJSON CHECK_APPLLDM  "$CHECK_APPLLDM"
printf  "\t},\n" >> $FILE_NAME

echo -e "CRONTAB_BKUP_START"

CRONTAB_BKUP_START=$CRONTAB_BKUP_START
outputJSON CRONTAB_BKUP_START "$CRONTAB_BKUP_START"
printf  "\t},\n" >> $FILE_NAME

echo -e "S_PIDS_DIR"

S_PIDS_DIR=$S_PIDS_DIR
outputJSON S_PIDS_DIR "$S_PIDS_DIR"
printf  "\t},\n" >> $FILE_NAME

echo -e "CHECK_PIDS_DIR"

CHECK_PIDS_DIR=$CHECK_PIDS_DIR
outputJSON CHECK_PIDS_DIR "$CHECK_PIDS_DIR"
printf  "\t},\n" >> $FILE_NAME

echo -e "S_OACORE_NPROCS"

S_OACORE_NPROCS=$S_OACORE_NPROCS
outputJSON S_OACORE_NPROCS "$S_OACORE_NPROCS"
printf  "\t},\n" >> $FILE_NAME

echo -e "CHECK_OACORE"

CHECK_OACORE=$CHECK_OACORE
outputJSON CHECK_OACORE "$CHECK_OACORE"
printf  "\t},\n" >> $FILE_NAME

echo -e "CHECK_RESPONSE_XMS"

CHECK_RESPONSE_XMS=$CHECK_RESPONSE_XMS
outputJSON CHECK_RESPONSE_XMS "$CHECK_RESPONSE_XMS"
printf  "\t},\n" >> $FILE_NAME

echo -e "CHECK_SIZE_REPORTS"

CHECK_SIZE_REPORTS=$CHECK_SIZE_REPORTS
outputJSON CHECK_SIZE_REPORTS "$CHECK_SIZE_REPORTS"
printf  "\t},\n" >> $FILE_NAME

echo -e "ECHO_TWO_TASK"

ECHO_TWO_TASK=$ECHO_TWO_TASK
outputJSON ECHO_TWO_TASK "$ECHO_TWO_TASK"
printf  "\t},\n" >> $FILE_NAME

echo -e "TOOLS_TWO_TASK"

TOOLS_TWO_TASK=$TOOLS_TWO_TASK
outputJSON TOOLS_TWO_TASK "$TOOLS_TWO_TASK"
printf  "\t},\n" >> $FILE_NAME

echo -e "CP_TWO_TASK"

CP_TWO_TASK=$CP_TWO_TASK
outputJSON CP_TWO_TASK "$CP_TWO_TASK"
printf  "\t},\n" >> $FILE_NAME

echo -e "S_TWO_TASK"

S_TWO_TASK=$S_TWO_TASK
outputJSON S_TWO_TASK "$S_TWO_TASK"
printf  "\t},\n" >> $FILE_NAME

echo -e "CHECK_JDBC_URL"

CHECK_JDBC_URL=$CHECK_JDBC_URL
outputJSON CHECK_JDBC_URL "$CHECK_JDBC_URL"
printf  "\t},\n" >> $FILE_NAME

echo -e "ENCRYPTION_WALLET"

ENCRYPTION_WALLET=$ENCRYPTION_WALLET
outputJSON ENCRYPTION_WALLET "$ENCRYPTION_WALLET"
printf  "\t},\n" >> $FILE_NAME

echo -e "LS_DEV_RANDOM"

LS_DEV_RANDOM=$LS_DEV_RANDOM
outputJSON LS_DEV_RANDOM "$LS_DEV_RANDOM"
printf  "\t},\n" >> $FILE_NAME

echo -e "GREP_SECURE_RANDOM"

GREP_SECURE_RANDOM=$GREP_SECURE_RANDOM
outputJSON GREP_SECURE_RANDOM "$GREP_SECURE_RANDOM"
printf  "\t},\n" >> $FILE_NAME

echo -e "GREP_JAVA_SECURITY"

GREP_JAVA_SECURITY=$GREP_JAVA_SECURITY
outputJSON GREP_JAVA_SECURITY "$GREP_JAVA_SECURITY"
printf  "\t},\n" >> $FILE_NAME

echo -e "OSWATCHER"

OSWATCHER=$OSWATCHER
outputJSON OSWATCHER "$OSWATCHER"
printf  "\t},\n" >> $FILE_NAME

echo -e "S_FORMS_LAUNCH_METHOD"

S_FORMS_LAUNCH_METHOD=$S_FORMS_LAUNCH_METHOD
outputJSON S_FORMS_LAUNCH_METHOD "$S_FORMS_LAUNCH_METHOD"
printf  "\t}\n" >> $FILE_NAME

echo -e "Writing footer to JSON file..."

printf "}" >> $FILE_NAME

echo -e "\033[1;32mDone.\033[0m"
